window.onload = function(){
  var date = new Date();
}

var slideIndex = 0;

function carousel() {
  var i;
  var x = document.getElementsByClassName("logoimage");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";
  }
  slideIndex++;
  if (slideIndex > x.length) {
      slideIndex = 1;
}
  x[slideIndex-1].style.display = "block";
  setTimeout(carousel, 60000); 
}

function clock() {
  var dt = new Date();
  var d = document.getElementById("currentDate");
  d.innerHTML =dt.toLocaleString();
  setInterval(clock, 1000);
}

//w3 schools
function myAccFunc() {
  var x = document.getElementById("tryacc");
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
 
  } else { 
    x.className = x.className.replace(" w3-show", "");

  }
}

function myAccFunc2() {
  var y = document.getElementById("tryacc2");
  if (y.className.indexOf("w3-show") == -1) {
    y.className += " w3-show";
 
  } else { 
    y.className = y.className.replace(" w3-show", "");

  }
}

function red() {
  var headercolor = document.getElementById("header");
  var menucolor = document.getElementsByClassName("menu");
  var footercolor = document.getElementById("footer");
  headercolor.style.background = "rgb(105, 6, 26)";
  menucolor[0].style.background = "rgb(105, 6, 26)";
  footercolor.style.background = "rgb(105, 6, 26)";
}

function blue() {
  var headercolor = document.getElementById("header");
  var menucolor = document.getElementsByClassName("menu");
  var footercolor = document.getElementById("footer");
  headercolor.style.background = "rgb(6, 53, 100)";
  menucolor[0].style.background = "rgb(6, 53, 100)";
  footercolor.style.background = "rgb(6, 53, 100)";
}

function green() {
  var headercolor = document.getElementById("header");
  var menucolor = document.getElementsByClassName("menu");
  var footercolor = document.getElementById("footer");
  headercolor.style.background = "rgb(6, 85, 6)";
  menucolor[0].style.background = "rgb(6, 85, 6)";
  footercolor.style.background = "rgb(6, 85, 6)";
}


