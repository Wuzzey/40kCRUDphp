<?php

$local = true;
$root = $_SERVER["DOCUMENT_ROOT"] . "/website";

if ($local == false) {
    $root = $_SERVER["CONTEXT_DOCUMENT_ROOT"];
}
require($root . '/includes/page.php');

$edit = new Page();

class Edit extends Page
{

    public function Display()
    {
        //require_once('../../includes/database.php');
        require_once("profiledal.php");
        echo "<html>\n<head>\n";
        $this->DisplayTitle();
        $this->DisplayKeywords();
        $this->DisplayStyles();
        echo "</head>\n<body>\n";
        $this->DisplayHeader();
        $this->DisplayMenu();
        echo $this->content;

        @$id = $_REQUEST['id'];
        ob_start();
        ob_start();
        if (isset($id)) {
            //echo "user ID: " . $id;
            $p = new ProfileDAL($id);
            $profile = $p->profile;
            $user = $p->user;
            $roles = $p->userRole;
         //   $checked = $user['active'] ==  1  ? "checked" : "";

?>
            <form method="post" enctype="multipart/form-data">

                <div class="card card-default">
                    <div class="card-body">
                        <div class="row">
                            <div class="col">
                                <div class="card card-default">
                                    <div class="card-header">
                                        Profile Picture
                                    </div>
                                    <div class="card-body">
                                        <img id="profile_picture" class="mainProfile" src="pictures/<?= $profile['picture'] ?>" alt='Profilepicture' /><br>
                                   
                                    </div>
                                    <div class="card-footer">
                                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#UploadProfileImage">
                                            Upload Image
                                        </button>

                                    </div>
                                </div>

                                <small>
                                    note: New profile pictures will not be saved until you click the save buttom below.
                                </small>
                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <input type="hidden" id="userid" name="userid" value="<?= $profile['iduser'] ?>">
                                    <label for="FirstName">FirstName</label>
                                    <input type="text" class="form-control" id="FirstName" name="FirstName" aria-describedby="FirstNameHelp" placeholder="Enter First Name" required value="<?= $profile['first_name'] ?>">
                                    <small id="FirstNameHelp" class="form-text text-muted">Enter your first name</small>
                                </div>
                                <div class="form-group">
                                    <label for="LastName">Last Name</label>
                                    <input type="text" class="form-control" id="LastName" aria-describedby="LastNameHelp" Name="LastName" placeholder="Enter Last Name" value="<?= $profile['last_name'] ?>">
                                    <small id="LastNameHelp" class="form-text text-muted">Enter your Last Name</small>
                                </div>
                                <div class="form-group">
                                    <label for="MiddleName">Middle Name</label>
                                    <input type="text" class="form-control" id="MiddleName" aria-describedby="MiddleNameHelp" Name="MiddleName" placeholder="Enter Middle Name" value="<?= $profile['middle_name'] ?>">
                                    <small id="MiddleNameHelp" class="form-text text-muted">Enter your Middle Name</small>
                                </div>
                                <div class="form-group">
                                    <label for="DOB">Date Of Birth</label>
                                    <input type="date" class="form-control" id="DOB" aria-describedby="DOBHelp" Name="DOB" placeholder="Enter Date Of Birth" value="<?= $profile['date_of_birth'] ?>">
                                    <small id="DOBHelp" class="form-text text-muted">Enter your Date Of Birth</small>
                                </div>
                            </div>
                            <div class='col'>
                                <div class="row">
                                    <div class="col">
                                        <div class="form-group">
                                            <label for= "Color">color</label>
                                            <input type="color" class="colorbox" id="color" value="<?=$profile['color']?>">
                                        </div>
                                    </div>
                                    <div class ='col'>
                                        <div class="form-check">
                                           <input type = "checkbox" class = "form-check-input" id="Active" <?=$checked ?>>
                                           <label class="form-check-label" for="Active">Active</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>




<?php
        } else {
            echo "Invalid ID!";
        }



        $this->DisplayFooter();
    }
}

$edit = new Edit();  
$result = ob_get_clean();
$edit->content = $result;

$edit->display();

?>