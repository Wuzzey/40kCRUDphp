<?php
require_once("../includes/database.php");

class ProfileDAL{
    protected $profile;
    protected $user;
    protected $email;
    protected $address;
    protected $phone;
    protected $userRole;
    protected $allRoles;
    protected $cn;
    protected $db;
    protected $stmt;
    public function __set($attribute, $value){
        if (property_exists($this, $attribute)){
            $this->$attribute = $value;
            echo "Updated {$attribute} to {$value}";
        }
        else{
            echo "Failed to update {$attribute}";
        }
    }

    public function __get($name){
        return $this->$name;
    }
    public function LoadProfile($id){
        $this->cn = $this->db->NewConnection();
        $sql = "Select * from user where iduser = " . $id;
        $this ->user = $this->db->getArray($sql);
        $sql = "Select * from profile where iduser = " . $id;
        $this ->profile = $this->db->getArray($sql);
        $sql = "Select * from address where iduser = " . $id;
        $this ->address = $this->db->getAll($sql);
        $sql = "Select * from phone where iduser = " . $id;
        $this ->phone = $this->db->getAll($sql);
        $sql = "Select * from email where iduser = " . $id;
        $this ->email = $this->db->getAll($sql);
        $sql = "Select * from vwuser where iduser = " . $id;
        $this ->userRole = $this->db->getAll($sql);
        $sql = "Select * from role";
        $this ->allRoles = $this->db->getAll($sql);
        
    }
    function __SaveProfile($userid, $firstname, $lastname, $middlename, $dateofbirth, $color, $about, $active, $mode){
        $sql ="";
        $isActive = $active=="on"?1:0;
        if($mode=='edit'){
            $profileid = $this->profile['idprofile'];
            
            $sql= "update profile set ";
            $sql= "first_name=?,last_name=?,middle_name=?,date_of_birth=?,color=?,about=?";
            $sql= "where idprofile=?";
            $cn = $this->db->NewConnection();
            $stmt=$cn->prepare($sql);
            if(!$stmt->bind_param("ssssssi", $firstname, $lastname, $middlename, $dateofbirth, $color, addslashes($about), $profileid )){
                return "Error: Parameter binding failed";
            }
            if(!$stmt->execute()){
                return "Error: execute failed: (". $stmt->errno.")".$stmt->error;
            }

        }
        if($mode=='new'){
            $profileid = $this->profile['idprofile'];
            $sql= "insert into profile(iduser,first_name,last_name,date_of_birth,color,about,active";
            $sql .= "?,?,?,?,?,?,?,?";
            $cn = $this->db->NewConnection();
            $stmt=$cn->prepare($sql);
            if(!$stmt->bind_param("i ssssssi",$userid, $firstname, $lastname, $middlename, $dateofbirth, $color, addslashes($about), $active )){
                return "Error: Parameter binding failed";
            }
            if(!$stmt->execute()){
                return "Error: execute failed: (". $stmt->errno.")".$stmt->error;
            }
            else{
                return "Error: invalid operation, mode not def" ;
            }
           

        }
        else{
            return "Success: profile saved";
        }
        

    }
    function __construct($id =0)
    {
        $this->db = new database();
        if($id > 0){
            $this->LoadProfile($id);
        }
    }

}