<?php

$local = true;
$root = $_SERVER["DOCUMENT_ROOT"] . "/website";

if ($local == false) {
    $root = $_SERVER["CONTEXT_DOCUMENT_ROOT"];
}
require($root . '/includes/page.php');

$profile = new Page();

class Profile extends Page
{

    public function Display()
    {
        //require_once('../../includes/database.php');
        require_once("profiledal.php");
        echo "<html>\n<head>\n";
        $this->DisplayTitle();
        $this->DisplayKeywords();
        $this->DisplayStyles();
        echo "</head>\n<body>\n";
        $this->DisplayHeader();
        $this->DisplayMenu();
        echo $this->content;

        @$id = $_REQUEST['id'];
        ob_start();

        if (isset($id)) {
            //echo "user ID: " . $id;
            $p = new ProfileDAL($id);
            $profile = $p->profile;
            $user = $p->user;
            $roles = $p->userRole;
            $emails = $p->email;
            $addresses = $p->address;
            $phone = $p->phone;

?>

            <div class="row">
                <div class="col">
                    <div class="card card-default" style="min-width:400px">
                        <div class="card-header">
                            <div class='row'>
                                <div class='col'>
                                    <?= $p['first_name'] ?>'s Profile
                                </div>
                                <div class="col float-right actionitem" style="text-align:right">
                                    <i id='EditProfile' class='fa fa-pencil-square-o' title="Edit the profile"></i>
                                </div>
                            </div>

                        </div>
                        <div class="card-body">
                            <p>
                                <img class="mainProfile" src="pictures/<?= $p['picture'] ?>" alt='Profilepicture'>
                            </p>
                            <?php
                            echo "User ID: <label id='User Id'>" . $profile['iduser'] . "</label>" . "<br/>";
                            echo "Name: " . $profile['first_name'] . " " . $profile['middle_name'] . " " . $profile['last_name'] . "<br/>";
                            echo "Date of Birth: " . $profile['date_of_birth'] . "<br/>";
                            echo "Active: " . $user['active'] . "<br/>";
                            echo "Last Login: " . $user['last_login'] . "<br/>";
                            ?>
                            Color: <input type="color" id="colorpicker" class=" colorbox" value="<?= $profile['color'] ?>">
                            </input>
                            <br><br>
                            <?php echo "About: " . nl2br($profile['about']);
                            ?>
                        </div>
                    </div>

                </div>

                <div class="col">
                    <div class="card card-default">
                        <div class="card-header">
                            <div class='row'>
                                <div class='col'>
                                    Emails
                                </div>
                                <div class='col float-right actionitem' style=' text-align:right'>
                                    <i id='EditEmail' class='fa fa-pencil-square-o' title="Edit the email"></i>
                                </div>
                            </div>
                        </div>
                        <div class="card-body" style="padding: 10px">
                            <table id="users" class="table table-bordered table-hover">
                                <thead class="thead-dark">
                                    <tr>
                                        <th>Type</th>
                                        <th>Email</th>
                                        <th>Default</th>

                                    </tr>

                                </thead>
                                <tbody>
                                    <tr>
                                        <?php
                                        foreach ($emails as $e) {
                                            $checked = $e['default'] = 1 ? " Checked" : "";
                                            echo "<tr>";
                                            echo "<td>" . $e['email_type'] . "</td>";
                                            echo "<td>" . $e['email_address'] . "</td>";
                                            echo "<td><input type ='checkbox' id = 'emaildefault'" . $checked . "</td>";
                                            echo "</tr>";
                                        }
                                        ?>
                                    </tr>
                                </tbody>
                            </table>


                        </div>

                    </div>
                </div>

            </div>
            <script>
                var id = $('#UserId').html();
                $('#EditProfile').click(() =>{
                    window.location = "editprofile.php?id="+id;
                });
                $('#EditEmail').click(() =>{
                    window.location = "editemail.php?id="+id;
                });

                
                
            </script>

<?php
        } else {
            echo "Invalid ID!";
        }



        $this->DisplayFooter();
    }
}

$profile = new Profile();
$result = ob_get_clean();
$profile->content = $result;

$profile->Display();

?>