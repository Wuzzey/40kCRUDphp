<?php
$local = true;
$root = $_SERVER["DOCUMENT_ROOT"] ."/website";

if ($local == false) {
    $root = $_SERVER["CONTEXT_DOCUMENT_ROOT"];
}

include($root .'/includes/header.php');
include($root .'/includes/menu.php');
?>

<h2>About me</h2>
<h3> A little bio: </h3>
<p>My name is Max Fuzzey. I will be graduating this year in the fall with a BS in computer science.</p>
<h3> Hobbies: </h3>
<p>Playing drums, guitar, video games, and Warhammer 40k model making/gaming</p>
<img id="cimage1" src="images/content1.jpg" class="contentimage" alt="content1">
<img id="cimage2" src="images/content2.JPG" class="contentimage" alt="content1">
<h3> Favorite quote: </h3>
<p style="font-style: italic;">&quot The only true wisdom is knowing that you know nothing. &quot
    <br />&#8211 Socrates, probably</p>
<h3> Why do you love programming: </h3>
<p>I love learning about a subject that has infinite avenues to explore.</p>
<h3> Sample text to prove scroll is working </h3>


<?php
include($root . '/includes/footer.php');
?>
