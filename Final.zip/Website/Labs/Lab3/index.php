
<?php
            $local = true;
            $root = $_SERVER["DOCUMENT_ROOT"].'/website';
            if($local== false){
                $root = $_SERVER["CONTEXT_DOCUMENT_ROOT"];
            }
           
            include($root.'/includes/header.php');
            include($root.'/includes/menu.php');
        ?>
         
       <div class="col">
            <div class="content ">      
            <a id="subtitle" class="HeaderSubTitle" href="./">
                    Lab 3
                </a>          
                <hr />
                <h3>My Simple Calculator</h3>
                <form action="calculate.php" method="POST">
                <div class="form-group">
                    <table>
                        <tr>
                            <td><label for="number1" >Number 1: </label></td>
                            <td><input id="number1" type="text" name="number1" class="form-control"></td>
                        </tr>
                        <tr>
                            <td><label for="number2" >Number 2: </label> </td>
                            <td><input id="number2" type="text" name="number2" class="form-control"></td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding:10px;">
                            <input type="submit" name="function" value="Add" class="btn btn-primary">
                            <input type="submit" name="function" value="Subtract" class="btn btn-primary">
                            <input type="submit" name="function" value="Multiply" class="btn btn-primary">
                            <input type="submit" name="function" value="Divide" class="btn btn-primary">
                            </td>
                        </tr>
                    </table>
                </div>
                </form>
                
                </div>
        </div>
                <?php 
                include($root.'/includes/footer.php');
                ?>