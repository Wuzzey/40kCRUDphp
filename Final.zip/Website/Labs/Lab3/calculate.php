
<?php
              $local = true;
              $root = $_SERVER["DOCUMENT_ROOT"].'/website';
              if($local== false){
                  $root = $_SERVER["CONTEXT_DOCUMENT_ROOT"];
              }
             
              include($root.'/includes/header.php');
              include($root.'/includes/menu.php');
        
    echo '<div class="content"><br><h2>Results</h2>';
    
    echo "Function: ". $_POST['function']."<br>";
    echo "<br>Number 1: ".$_POST['number1']. "<br>Number 2: ".$_POST['number2']."<br>";

    if (is_numeric($_POST['number1'])&&is_numeric($_POST['number2'])){

    $number1 = $_POST['number1'];   
    $number2 = $_POST['number2'];   
   
    if ($_POST['function'] == "Subtract"){
        $equation = $number1 . '-'. $number2 . '='. ($number1 - $number2);
        echo '<div class="alert alert-primary" role="alert"><strong>'.$equation.'</strong></div>';
    }
    
    if ($_POST['function'] == "Multiply"){
        $equation = $number1 . 'X'. $number2 . '='. ($number1 * $number2);
        echo '<div class="alert alert-primary" role="alert"><strong>'.$equation.'</strong></div>';
    }
    
    if ($_POST['function'] == "Add"){
        $equation = $number1 . '+'. $number2 . '='. ($number1 + $number2);
        echo '<div class="alert alert-primary" role="alert"><strong>'.$equation.'</strong></div>';
    }
    
    if ($_POST['function'] == "Divide"){
        if($number2==0){
            echo '<div class="alert alert-danger" role="alert"><strong>Cannot Divide by Zero!</strong></div>';
        }
        else{
        $equation = $number1 . '/'. $number2 . '='. ($number1 / $number2);
        echo '<div class="alert alert-primary" role="alert"><strong>'.$equation.'</strong></div>';
        }
    }
}
    
    else{
        echo '<div class="alert alert-danger" role="alert"><strong>both numbers must be numberic!</strong></div>';
    }
         
    echo '</div><br> <a href="index.php" class="btn btn-primary">Back</a>';

    include($root.'/includes/footer.php');
?>
        
  