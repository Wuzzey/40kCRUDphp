<?php
function processData($data)
{

    $dataArray = json_decode($data, true);

    if (is_array($dataArray)) {
        $result = "<table class='arraytable1'>";
        foreach ($dataArray as $key => $val) { //level one
            $result .= "<tr><td class='key'>" . $key . ": </td><td class='value'>";
            if (gettype($val) == "array") {
                $result .= "<table class='arraytable1'>";
                foreach ($val as $subkey => $subval) { //level two
                    $result .= "<tr><td class='key2'>" . $subkey . ": </td><td class='value2'>";
                    if (gettype($subval) == "array") { //level three
                        $result .= "<table class='arraytable1'>";
                        foreach ($subval as $lowkey => $lowval) { //level four
                            $result .= "<tr><td class='key3'>" . $lowkey . ": </td><td class='value3'>";

                            if (gettype($lowval) != "array") {

                                $result .=  $lowval . "</td></tr>";
                            } else {
                                $result .= "</td></tr>";
                            }
                        }
                        $result .= "</table>";
                    } else {
                        $result .= $subval . "</td></tr>";
                    }
                }
                $result .= "</table>";
            } else {
                $result .= $val . "</td></tr>";
            }
        }
        $result .= "</table>";
    } else {
        echo "not a valid JSON format!";
    }
    return $result;
}




function processRecursive($data2, $result2){
    if (gettype($data2) == "string"){
    $dataArray2 = json_decode($data2, true);
    }
    else{
        $dataArray2 = $data2;
    }
    if (is_array($dataArray2)) {
        $result2 .= "<table class='arraytable1'>";
        foreach ($dataArray2 as $key2 => $val2) { //level one
            $result2 .= "<tr><td class='key'>" . $key2 . ": </td><td class='value'>";
            if (gettype($val2) == "array") {
                $result2 .= "<table class='arraytable1'>";
            }
            else {
                $result2 .= "</td></tr>";
            }

        }
        $result2 .= "</table>";
        processRecursive($key2, $result2);
    }
    else{
        return $result2;
    }
    

}




function upload($filename, $dir)
{
    $uploadOK = true;

    $file = $_FILES[$filename]["name"];
    $target = $dir.$file;
    $fileType = strtolower(pathinfo($target, PATHINFO_EXTENSION));
    if ($_FILES[$filename]["size"] > 500000) {
        echo "sorry the file is too large!";
        $uploadOK = false;
    }
    if ($fileType != "json") {
        echo "Invalid File Type!";
        $uploadOK = false;
    }
    if ($uploadOK == false) {
        echo "File was not uploaded. ";
    } else {
        if (move_uploaded_file($_FILES[$filename]["tmp_name"], $target)) {
            echo "The file" . basename($file) . " had been uploaded";
        } else {
            echo "Error in JSON file upload, Check correctness of JSON data";
        }
    }
    return $target;
}
