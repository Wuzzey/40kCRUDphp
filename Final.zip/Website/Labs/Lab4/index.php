<?php
$local = true;
$root = $_SERVER["DOCUMENT_ROOT"] ."/website";
if ($local == false) {
    $root = $_SERVER["CONTEXT_DOCUMENT_ROOT"];
}

include($root .'/includes/header.php');
include($root .'/includes/menu.php');
include('functions.php');
echo '<link href="lab4.css" rel="stylesheet">';
echo '<a id="subtitle" class="HeaderSubTitle" href="./">' . "Lab 4" . "</a>" . "<br>";
if (isset($_POST["file"])) {
    $dir = "uploads/";
    $target = upload("jsonFile", $dir);
    $data = file_get_contents($target);
    $result = processData($data);
    $result2 = processRecursive($data, '');
    
}

?>


<form action="index.php" method='post' enctype="multipart/form-data">
    <div class="wrapper">
        <input type="file" name="jsonFile" id="jsonFile" class="btn btn-primary">
        <input type="submit" value="Upload Json File" name="file" class="btn btn-primary">
    </div>
</form>
<?php
    if(isset($_POST['file'])){
?>
<div class="row">   
    <div class="col">
        <div class="row" style="border:solid 1px silver; background-color:lightsteelblue; font-size:larger">Interative Pattern</div>
        <div class="row">

        <?php
        echo $result;
        ?>
        </div>
    </div>
    <div class="col">
        <div class="row" style="border:solid 1px silver; background-color:lightsteelblue; font-size:larger">Recursive Pattern</div>
        <div class="row">
        <?php
        echo $result2;
        ?>

        </div>
    </div>
</div>
<?php
}
include($root . '/includes/footer.php');
?>