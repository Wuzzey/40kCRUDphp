
      <?php

$local = true;
$root = $_SERVER["DOCUMENT_ROOT"] ."/website";

if ($local == false) {
    $root = $_SERVER["CONTEXT_DOCUMENT_ROOT"];
}
    require ($root. '/includes/page.php');
   
   $lab7 = new Page();
    
class Lab7 extends Page{
    
    public function Display(){
        require_once('../../includes/database.php');
        echo "<html>\n<head>\n";
        $this -> DisplayTitle();
        $this -> DisplayKeywords();
        $this -> DisplayStyles();
        echo "</head>\n<body>\n";
        $this -> DisplayHeader();
        $this -> DisplayMenu();
        echo $this->content;
        
        
        $sql = "select * from vwuser";
        $results = $db -> getAll($sql);
        ob_start(); 

        
        ?>
<table id="users" class="table table-bordered table-hover">
        <thead class="thead-dark">
            <tr>
                <th>ID</th>
                <th>Picture</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Age</th>
                <th>User Name</th>
                <th>Role</th>
            </tr>
        
        </thead>
        <tbody>
            
            <?php
            foreach ($results as $r){
                echo "<tr>";
                echo "<td><span id='userid'>".$r['iduser']."</span></td>";
                echo "<td><img class='ProfileImage' src='../../profile/pictures/" . $r['picture']."'.alt='".$r['picture'] ."'/></td>";
                echo "<td>" . $r['first_name']. "</td>";
                echo "<td>" . $r['last_name']. "</td>";
                echo "<td>" . $r['Age']. "</td>";
                echo "<td>" . $r['username']. "</td>";
                echo "<td>" . $r['Role']. "</td>";
                echo "</tr>";
                
              
            }
            ?>
            
        </tbody>
</table>

        <?php
        
  

        $this -> DisplayFooter();


    }
}

$lab7 = new Lab7();
$result = ob_get_clean();


$lab7 -> Display();

?>

<script>
    $("#users tr").on('click', function(){
        var currentRow = $(this).closest("tr");
        var id = currentRow.find("td span").text();
        window.location =  "../../profile/?id=" + id;
    }
    );
</script>