<?php
namespace Motors;
class Vehicle{
    protected $name;
    protected $axels;
    protected $body;
    protected $wheels;
    protected $engine;

    public function __set($attribute, $value){
        if(property_exists($this, $attribute)){
            $this->$attribute=$value;
           // echo "Updated {$attribute} to {$value}.<br/>";
        }
        else{
          //  echo "failed to update {$attribute}.<br/>";
        }
    }

    public function __get($attribute){
        return $this->$attribute;
    }

    public function __getName(){
        return $this->name;
    }

    public function __construct($name){

        $this->name=$name;
    }

    public function build(){
        echo "Name: ".$this->name."<br/>";
        echo "Axels: ".$this->axels."<br/>";
        echo "Body: ".$this->body."<br/>";
        echo "Wheels: ".$this->wheels."<br/>";
        echo "Engine: ".$this->engine."<br/>";
    }
    
}

class Car extends Vehicle{
    use Drive, Music;
    protected $make;
    protected $model;
    protected $year;


    public function __set($attribute, $value){
        if(property_exists($this, $attribute)){
            $this->$attribute=$value;
          //  echo "Updated {$attribute} to {$value}.<br/>";
        }
        else{
          //  echo "failed to update {$attribute}.<br/>";
        }
    }

    public function __get($attribute){
        return $this->$attribute;
    }
    public function __construct($name){

        $this->name=$name;
    }

    public function build(){
        echo "<h2>I am a Car named:  ".$this->name."</h2><br/>";
        parent::build();
        echo "Make: ".$this->make."<br/>";
        echo "Model: ".$this->model."<br/>";
        echo "Year: ".$this->year."<br/>";
    }
    
    public function rev(){
        echo "Revving in my awesome car named ".$this->name."!<br/>";
    }
    

}

class Truck extends Vehicle{
    use Drive, Music;
    protected $make;
    protected $model;
    protected $year;
    protected $powertrain;

    public function __set($attribute, $value){
        if(property_exists($this, $attribute)){
            $this->$attribute=$value;
        //    echo "<br/>.Updated {$attribute} to {$value}.<br/>";
        }
        else{
           // echo "failed to update {$attribute}.<br/>";
        }
    }

    public function __get($attribute){
        return $this->$attribute;
    }
    public function __construct($name){

        $this->name=$name;
    }

    public function build(){
     
        echo "<h2>I am a Truck named:  ".$this->name."</h2><br/>";
        parent::build();
        echo "Powertrain: ".$this->powertrain."<br/>";
        echo "Make: ".$this->make."<br/>";
        echo "Model: ".$this->model."<br/>";
        echo "Year: ".$this->year."<br/>";
    }
    
    function rev(){
        echo "Powering through in my Tuck named ".$this->name."!<br/>";
    }
    
    

}




class Bike extends Vehicle{
    use Drive, Music;
    protected $make;
    protected $motor;
    protected $model;
    protected $year;


    public function __set($attribute, $value){
        if(property_exists($this, $attribute)){
            $this->$attribute=$value;
          //  echo "Updated {$attribute} to {$value}.<br/>";
        }
        else{
            //echo "failed to update {$attribute}.<br/>";
        }
    }

    public function __get($attribute){
        return $this->$attribute;
    }
    public function __construct($name){

        $this->name=$name;
    }

    public function build(){
     
        echo "<h2>I am a Bike named:  ".$this->name."</h2><br/>";
        parent::build();
        echo "Model: ".$this->model."<br/>";
        echo "Year: ".$this->year."<br/>";
    }


    function rev(){
        echo "Speeding through in my ".$this->make." ".$this->model."!<br/>";
    }
    
    

}

trait Drive{
    function rev($vehicle){
        echo "revving in my ".$vehicle."<br/>";
        
    }
}

trait Music{
    function play($song){
        echo "Jamming to ".$song."!<br/>";
    }
}
?>