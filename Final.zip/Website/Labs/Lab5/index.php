
      <?php

  
use Motors\Vehicle;
use Motors\Car;
use Motors\Truck;
use Motors\Bike;

$local = true;
$root = $_SERVER["DOCUMENT_ROOT"] ."/website";

if ($local == false) {
    $root = $_SERVER["CONTEXT_DOCUMENT_ROOT"];
}



    require ($root. '/includes/page.php');
    require($root. "/Labs/Lab5/vehicle.php");
class Lab5 extends Page{

  

    public function Display(){
       

        echo "<html>\n<head>\n";
        $this -> DisplayTitle();
        $this -> DisplayKeywords();
        $this -> DisplayStyles();
        echo "</head>\n<body>\n";
        $this -> DisplayHeader();
        $this -> DisplayMenu();
        echo $this->content;
        $car = new Car("Generic sports car");
        $car ->axels = 2;
        $car ->body = "aluminum";
        $car ->wheels = 4;
        $car ->engine = "4 cylinder unleaded";
        $car ->make = "Nissan";
        $car ->model = "Skyline";
        $car ->year = 1998;
       $car ->build();
         $car->rev();
       $car->play("Deja Vu");

       $truck = new Truck("Marv");
    $truck ->axels = 2;
    $truck ->body = "Steel";
    $truck ->wheels = 4;
    $truck ->engine = "8 cylinder unleaded";
    $truck ->make = "Ford";
    $truck ->model = "F150";
    $truck ->year = 2020;
    $truck ->powertrain = "4X4";
    $truck ->build();
    $truck->rev();
    $truck->play("Meshuggah");

    $bike = new Bike("Generic Motorcycle");
    $bike ->axels = 2;
    $bike ->body = "poly Frame";
    $bike ->wheels = 2;
    $bike ->engine = "2 cylinder unleaded";
    $bike ->make = "Honda";
    $bike ->model = "CBR";
    $bike ->year = 2018;
    $bike ->build();
    $bike->rev();
    $bike->play("Igorr");

    echo "<br>";
    $carArray = (array)$car;
    Print_r($car);

    echo "<br>";
    $carArray = (array)$truck;
    Print_r($truck);

    echo "<br>";
    $carArray = (array)$bike;
    Print_r($bike);
        $this -> DisplayFooter();
        echo "</body>\n</html>\n";
    }


}

$lab5 = new Lab5();

$lab5 -> Display();

?>