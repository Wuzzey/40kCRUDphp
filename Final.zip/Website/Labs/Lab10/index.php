
      <?php
              $local = true;
              $root = $_SERVER["DOCUMENT_ROOT"].'/website';
              if($local== false){
                  $root = $_SERVER["CONTEXT_DOCUMENT_ROOT"];
              }
             
              include($root.'/includes/header.php');
              include($root.'/includes/menu.php');
        ?>
                <a id="subtitle" class="HeaderSubTitle" href="./">
                    Lab 10
                </a>
                <?php 
                include($root.'/includes/footer.php');
                ?>