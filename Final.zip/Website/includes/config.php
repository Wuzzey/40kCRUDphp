<?php

class configuration{
    public $local = true;
    public $directory = 'demo';
    public $useraccount = '~ics325su2009';
    public $dbuser = "root";
    public $dbpassword = "";
    public $database = "site2";
    public $docroot = "";
    public $root = "";
    
public function __get($name){
    return $this->$name;
}
public function __set($name, $value){
    $this->$name = $value;
}
}
?>