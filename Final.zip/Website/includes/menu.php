<div id="container" class="row" style="height: 100%;">

    <div id="menu" class="col" style="max-width: 210px; height: auto;">
        <div class="menu">
            <a id="subtitle" class="HeaderSubTitle" href="<?= $docRoot ?>./" style="padding-left: 10px;">
                Home
            </a>
            <button class="w3-button w3-block w3-left-align" onclick="myAccFunc()">
                Labs <i class="fa fa-caret-down"></i>
            </button>

            <div id="tryacc" class="w3-hide">
                <ul>
                    <li>
                        <a href="<?= $docRoot ?>Labs/Lab3/index.php">Lab 3</a>
                        </a>
                    </li>
                    <li>
                        <a href="<?= $docRoot ?>Labs/Lab4/index.php">Lab 4</a>
                        </a>
                    </li>
                    <li>
                        <a href="<?= $docRoot ?>Labs/Lab5/index.php">Lab 5</a>
                        </a>
                    </li>
                    <li>
                        <a href="<?= $docRoot ?>Labs/Lab6/index.php">Lab 6</a>
                        </a>
                    </li>
                    <li>
                        <a href="<?= $docRoot ?>Labs/Lab7/index.php">Lab 7</a>
                        </a>
                    </li>
                    <li>
                        <a href="<?= $docRoot ?>Labs/Lab8/index.php">Lab 8</a>
                        </a>
                    </li>
                    <li>
                        <a href="<?= $docRoot ?>Labs/Lab9/index.php">Lab 9</a>
                        </a>
                    </li>
                    <li>
                        <a href="<?= $docRoot ?>Labs/Lab10/index.php">Lab 10</a>
                        </a>
                    </li>
                </ul>
            </div>

            <button class="w3-button w3-block w3-left-align" onclick="myAccFunc2()">
                Project <i class="fa fa-caret-down"></i>
            </button>

            <div id="tryacc2" class="w3-hide">
                <ul>
                    <li>
                        <a href="<?= $docRoot ?>Projects/Phase1/index.php">Phase 1</a>
                        </a>
                    </li>
                    <li>
                        <a href="<?= $docRoot ?>Projects/Phase2/index.php">Phase 2</a>
                        </a>
                    </li>
                    <li>
                        <a href="<?= $docRoot ?>Projects/Phase3/index.php">Phase 3</a>
                        </a>
                    </li>
                    <li>
                        <a href="<?= $docRoot ?>Projects/Phase4/index.php">Phase 4</a>
                        </a>
                    </li>
                    <li>
                        <a href="<?= $docRoot ?>Projects/Final/index.php">Final</a>
                        </a>
                    </li>
                </ul>
            </div>
        </div>


    </div>
    <div class="col">
        <div class="content">