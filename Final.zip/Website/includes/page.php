<?php
require_once('config.php');

class Page{
public $content;
public $title = "lab";
public $keywords = "lab 5";
public $config;
//public $buttons = array("home"=>"")

public function __set($name, $value){
    $this -> $name = $value;
}
public function __construct(){
    $this->config = new configuration();
}

    

public function Display(){
    echo "<html>\n<head>\n";
    $this -> DisplayTitle();
    $this -> DisplayKeywords();
    $this -> DisplayStyles();
    echo "</head>\n<body>\n";
    $this -> DisplayHeader();
    $this -> DisplayMenu();
    echo $this->content;
    $this -> DisplayFooter();
    echo "</body>\n</html>\n";
}

public function DisplayTitle(){


}

public function DisplayKeywords(){

    
}

public function DisplayStyles(){
    ?>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <?php
    
}

public function DisplayHeader(){
    ?>
    <html>
    <head>
        <title>
            Max's site
        </title>
        <?php
             $local = true;
             $root = $_SERVER["DOCUMENT_ROOT"].'/website';
             if($local== false){
                 $root = $_SERVER["CONTEXT_DOCUMENT_ROOT"];
             }
            
             $docRoot = "http://localhost/website/";
             if($local== false){
                $docRoot = "http://sp-cfsics.metrostate.edu/~ics325su2009/";
            }
            

        ?>

    <script src="<?=$docRoot ?>js/site.js"></script>
    <link rel="stylesheet" href="<?=$docRoot ?>css/style.css">
    

</head>
<body>
    <div id="header" class="fixed-header">
        <div class="row">
            <div class ="col" id="headerimage" style="max-width: 320px;">
                <img src="<?=$docRoot ?>images/image1.png" class="logoimage" alt="logo1">
                <img src="<?=$docRoot ?>images/image2.png" class="logoimage" alt="logo2">
                <img src="<?=$docRoot ?>images/image4.png" class="logoimage" alt="logo4">
                <img src="<?=$docRoot ?>images/image5.png" class="logoimage" alt="logo5">
            

            </div>
            <div class ="col" style="text-align: left;">
                <span id="HeaderTitle" class="HeaderTitle">
                    Max's site
                </span>
                <br />
                <a id="subtitle" class="HeaderSubTitle" href="./">
                    Home
                </a>
            </div>
            <div style="max-width: 260px;">
                <img src="<?=$docRoot ?>images/logo-white.png" alt="MetroLogo" style="width: 250px; align-self: right;">
            </div>
            <div class="col" style="max-width: 200px;">
                <image id="profilepic" src = "<?=$docRoot?>images/profile.png"></image>
                <div id="colors">
                    <table id="colortable">
                        <tr>
                            <td>
                               
                                    <button id="redColor" class="w3-button w3-block w3-left-align" onclick="red()">
                                        </button>
                                
                            </td>
                        </tr>
                        <tr>
                            <td>
                                
                                    <button id="blueColor" class="w3-button w3-block w3-left-align" onclick="blue()">
                                        </button>
    
                            </td>
                        </tr>
                        <tr>
                            <td>
                                
                                    <button id="greenColor" class="w3-button w3-block w3-left-align" onclick="green()">
                                        </button>
                                
                            </td>
                        </tr>
                    </table>
                </div>

            </div> 
      </div>
    </div>
    <?php
}

public function DisplayMenu(){
    ?>

<?php
             $local = true;
             $root = $_SERVER["DOCUMENT_ROOT"].'/website';
             if($local== false){
                 $root = $_SERVER["CONTEXT_DOCUMENT_ROOT"];
             }
            
             $docRoot = "http://localhost/website/";
             if($local== false){
                $docRoot = "http://sp-cfsics.metrostate.edu/~ics325su2009/";
            }
            

        ?>
    <div id="container" class="row" style="height: 100%;">

    <div id="menu" class="col" style="max-width: 210px; height: auto;">
        <div class="menu">
            <a id="subtitle" class="HeaderSubTitle" href="<?= $docRoot ?>./" style="padding-left: 10px;">
                Home
            </a>
            <button class="w3-button w3-block w3-left-align" onclick="myAccFunc()">
                Labs <i class="fa fa-caret-down"></i>
            </button>

            <div id="tryacc" class="w3-hide">
                <ul>
                    <li>
                        <a href="<?= $docRoot ?>Labs/Lab3/index.php">Lab 3</a>
                        </a>
                    </li>
                    <li>
                        <a href="<?= $docRoot ?>Labs/Lab4/index.php">Lab 4</a>
                        </a>
                    </li>
                    <li>
                        <a href="<?= $docRoot ?>Labs/Lab5/index.php">Lab 5</a>
                        </a>
                    </li>
                    <li>
                        <a href="<?= $docRoot ?>Labs/Lab6/index.php">Lab 6</a>
                        </a>
                    </li>
                    <li>
                        <a href="<?= $docRoot ?>Labs/Lab7/index.php">Lab 7</a>
                        </a>
                    </li>
                    <li>
                        <a href="<?= $docRoot ?>Labs/Lab8/index.php">Lab 8</a>
                        </a>
                    </li>
                    <li>
                        <a href="<?= $docRoot ?>Labs/Lab9/index.php">Lab 9</a>
                        </a>
                    </li>
                    <li>
                        <a href="<?= $docRoot ?>Labs/Lab10/index.php">Lab 10</a>
                        </a>
                    </li>
                </ul>
            </div>

            <button class="w3-button w3-block w3-left-align" onclick="myAccFunc2()">
                Project <i class="fa fa-caret-down"></i>
            </button>

            <div id="tryacc2" class="w3-hide">
                <ul>
                    <li>
                        <a href="<?= $docRoot ?>Projects/Phase1/index.php">Phase 1</a>
                        </a>
                    </li>
                    <li>
                        <a href="<?= $docRoot ?>Projects/Phase2/index.php">Phase 2</a>
                        </a>
                    </li>
                    <li>
                        <a href="<?= $docRoot ?>Projects/Phase3/index.php">Phase 3</a>
                        </a>
                    </li>
                    <li>
                        <a href="<?= $docRoot ?>Projects/Phase4/index.php">Phase 4</a>
                        </a>
                    </li>
                    <li>
                        <a href="<?= $docRoot ?>Projects/Final/index.php">Final</a>
                        </a>
                    </li>
                </ul>
            </div>
        </div>


    </div>
    <div class="col">
        <div class="content">
    <?php
}

public function DisplayFooter(){
?>
</div>
    </div>
    <div id="footer" class="fixed-footer">
        <div class="row">
            <div class="col" style="text-align: left;">Accessed: <span id="currentDate"></span></div>
            <div class="col" style="text-align: center;">Copyright @ Metropolitan State Univercity</div>
            <div class="col" style="text-align: right;">Accessed By: <span id="accessedBy"> Max Fuzzey</span></div>
         </div>
    </div>
    <script>
        //start image carousel
        carousel();
        clock();
        
    </script>
</body>

</html> 
<?php
    
}



}


?>