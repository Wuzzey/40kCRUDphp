</div>
    </div>
    <div id="footer" class="fixed-footer">
        <div class="row">
            <div class="col" style="text-align: left;">Accessed: <span id="currentDate"></span></div>
            <div class="col" style="text-align: center;">Copyright @ Metropolitan State Univercity</div>
            <div class="col" style="text-align: right;">Accessed By: <span id="accessedBy"> Max Fuzzey</span></div>
         </div>
    </div>
    <script>
        //start image carousel
        carousel();
        clock();
        
    </script>
</body>

</html> 