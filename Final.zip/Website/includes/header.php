<html>
    <head>
        <title>
            Max's site
        </title>
        <?php
             $local = true;
             $root = $_SERVER["DOCUMENT_ROOT"].'/website';
             if($local== false){
                 $root = $_SERVER["CONTEXT_DOCUMENT_ROOT"];
             }
            
             $docRoot = "http://localhost/website/";
             if($local== false){
                $docRoot = "http://sp-cfsics.metrostate.edu/~ics325su2009/";
            }
            include($root.'/includes/external.php');

        ?>

    <script src="<?=$docRoot ?>js/site.js"></script>
    <link rel="stylesheet" href="<?=$docRoot ?>css/style.css">
    

</head>
<body>
    <div id="header" class="fixed-header">
        <div class="row">
            <div class ="col" id="headerimage" style="max-width: 320px;">
                <img src="<?=$docRoot ?>images/image1.png" class="logoimage" alt="logo1">
                <img src="<?=$docRoot ?>images/image2.png" class="logoimage" alt="logo2">
                <img src="<?=$docRoot ?>images/image4.png" class="logoimage" alt="logo4">
                <img src="<?=$docRoot ?>images/image5.png" class="logoimage" alt="logo5">
            

            </div>
            <div class ="col" style="text-align: left;">
                <span id="HeaderTitle" class="HeaderTitle">
                    Max's site
                </span>
                <br />
                <a id="subtitle" class="HeaderSubTitle" href="./">
                    Home
                </a>
            </div>
            <div style="max-width: 260px;">
                <img src="<?=$docRoot ?>images/logo-white.png" alt="MetroLogo" style="width: 250px; align-self: right;">
            </div>
            <div class="col" style="max-width: 200px;">
                <image id="profilepic" src = "<?=$docRoot?>images/profile.png"></image>
                <div id="colors">
                    <table id="colortable">
                        <tr>
                            <td>
                               
                                    <button id="redColor" class="w3-button w3-block w3-left-align" onclick="red()">
                                        </button>
                                
                            </td>
                        </tr>
                        <tr>
                            <td>
                                
                                    <button id="blueColor" class="w3-button w3-block w3-left-align" onclick="blue()">
                                        </button>
    
                            </td>
                        </tr>
                        <tr>
                            <td>
                                
                                    <button id="greenColor" class="w3-button w3-block w3-left-align" onclick="green()">
                                        </button>
                                
                            </td>
                        </tr>
                    </table>
                </div>

            </div> 
      </div>
    </div>