<?php

class configuration{
    public $local = true;
    public $directory = '';
    public $useraccount = '~root';
    public $dbuser = "root";
    public $dbpassword = "";
    public $database = "project";
    public $docroot = "";
    public $root = "";
    
    
public function __get($name){
    return $this->$name;
}
public function __set($name, $value){
    $this->$name = $value;
}
}
?>