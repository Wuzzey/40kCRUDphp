<html>

<head>
  <title>
    Final Site
  </title>
  <?php
  $local = true;
  $root = $_SERVER["DOCUMENT_ROOT"] . '/website';
  if ($local == false) {
    $root = $_SERVER["CONTEXT_DOCUMENT_ROOT"];
  }

  $docRoot = "http://localhost/website/";
  if ($local == false) {
    $docRoot = "http://sp-cfsics.metrostate.edu/~ics325su2009/";
  }

  include($root . '/Projects/finalincludes/finalExternal.php');
  ?>
  <script src="<?= $docRoot ?>/Projects/finaljs/finalsite.js"></script>
  <link rel="stylesheet" href="<?= $docRoot ?>/Projects/finalcss/style.css">


</head>

<body>
  <div id="header" class="fixed-header">


    <div class="row">
      <div class="lnav">
        <li class="menuItem"><a href="../Phase1/Allies.php">Allies</a></li>
        <li class="menuItem"><a href="../Phase1/Manufactorum.php">Manufactorum</a></li>
      </div>
      <div class="navimage">
        <a href="index.php"><img id="cimage2" src="../finalimages/mech.png" class="contentimage" alt="content1"></a>
      </div>
      <div class="rnav">
        <li class="menuItem"><a href="../Phase1/Enemies.php">Enemies</a></li>
        <li class="menuItem"><a href="../Phase1/BattleReport.php">Battle Report</a></li>
      </div>

      <div class="profileinfo">
      <li class="menuItem"><a href="../Phase1/Login.php">log in</a></li>
      
      </div>

    </div>
  </div>
</body>