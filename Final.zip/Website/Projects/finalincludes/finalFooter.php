</div>
    </div>
    <div id="footer" class="fixed-footer">
        <div class="row">
            <div class="col" style="text-align: left;">Accessed: <span id="currentDate"></span></div>

            <div class="col" style="text-align: right;">Accessed By: <span id="accessedBy"> Max Fuzzey</span></div>
         </div>
    </div>
    <script>
    
        clock();
        
    </script>
</body>

</html> 