
<?php
require_once('database.php');
class ProfileDal
{
    protected $battlereportid;
    protected $allyid;
    protected $itemid;
    protected $enemyid;
    protected $battledetails;
    protected $outcome;
    protected $battledate;
    protected $numberofenemy;
    protected $numberofally;
    protected $cn;
    protected $db;
   

    public function __construct($id = 0)
    {
        $this->db = new database();
        if ($id > 0) {
            $this->LoadProfile($id);
        }
    }
    public function __set($attribute, $value)
    {
        if (property_exists($this, $attribute)) {
            $this->$attribute = $value;
            echo "Updated {$attribute} to {$value}";
        } else {
            echo "Failed to update {$attribute}.";
        }
    }
    public function __get($name)
    {
        return $this->$name;
    }
    public function SaveProfile($battlereportid, $allyid, $itemid, $enemyid, $allyfaction, $outcome, $numberofenemy, $numberofally, $battledetails, $mode)

    {
        $sql = "";

        /*if ($mode == "edit") {
            $profileid = $this->profile['idprofile'];
            $sql = "update profile set ";
            $sql .= "iduser = '" . $allyname . "',";
            $sql .= "last_name = '" . $lastname . "',";
            $sql .= "middle_name = '" . $allyusername . "',";
            $sql .= "date_of_birth = '" . $dateofbirth . "',";
            $sql .= "color = '" . $color . "',";
            $sql .= "about = '" . addslashes($about) . "'";
            $sql .= " where idprofile = " . $profileid;
            //echo "<pre>" . $sql . "</pre><br>";
        } else*/
        if ($mode == "new") {
            $sql = "insert into battlereport(`battlereportid`,`allyid`,`itemid`,`enemyid`,`outcome`,`numberofenemy`,`numberofally`,`battledetails`) values(";
            $sql .= $battlereportid . ",";
            $sql .= "'" . $allyid . "',";
            $sql .= "'" . $itemid . "',";
            $sql .= "'" . $enemyid . "',";
            $sql .= "'" . $outcome . "',";
            $sql .= "'" . $numberofenemy . "',";
            $sql .= "'" . $numberofally . "',";
            $sql .= "'" . addslashes($battledetails) . "')";
        } else {
            return "Error: Invalid operation!";
        }


        $cn = $this->db->NewConnection();
        $result = $cn->query($sql);
        $msg = "Success: Saved the user profile.";
        if ($result == false) {
            $msg = "Error: There was an error saving the profile picture. " . $cn->errno . ": " . $cn->error .  $sql . "\n";
        }
        $this->db->CloseConnection();
        return $msg;
    }

    public function SaveProfilePicture($picture)
    {
        $sql = "";
        if ($picture != "") {
            $profileid = $this->profile['idprofile'];
            $sql = "update profile set ";
            $sql .= "picture = '" . $picture . "'";
            $sql .= " where idprofile = " . $profileid;
        } else {
            return "Error: Invalid operation!";
        }
        $cn = $this->db->NewConnection();
        $result = $cn->query($sql);
        $msg = "Success: Saved the profile picture.";
        if ($result == false) {
            $msg = "Error: There was an error saving the profile picture." . $cn->errno . ": " . $cn->error . "\n";
        }
        $this->db->CloseConnection();
        return $msg;
    }
    function LoadProfile($id)
    {
        $this->cn = $this->db->NewConnection();
        $sql = "Select * from user where iduser=" . $id;
        $this->user =  $this->db->getArray($sql);
        $sql = "Select * from profile where iduser=" . $id;
        $this->profile =  $this->db->getArray($sql);
        $sql = "Select * from address where iduser=" . $id;
        $this->address =  $this->db->getAll($sql);
        $sql = "Select * from phone where iduser=" . $id;
        $this->phone =  $this->db->getAll($sql);
        $sql = "Select * from email where iduser=" . $id;
        $this->email =  $this->db->getAll($sql);
        $sql = "Select * from vwuser where iduser=" . $id;
        $this->roles =  $this->db->getAll($sql);
        $sql = "Select * from role";
        $this->allroles =  $this->db->getAll($sql);

        $this->db->CloseConnection();
    }

    function RefreshProfile($id)
    {
        $this->cn = $this->db->NewConnection();
        $sql = "Select * from profile where iduser=" . $id;
        $this->profile = $this->db->getArray($sql);
        $this->db->CloseConnection();
        return $this->profile;
    }
}
