
<?php
require_once('database.php');
class ProfileDal
{

    protected $enemy;
    protected $enemyid;
    protected $enemytitle;
    protected $enemyfaction;
    protected $enemystrength;
    protected $enemypower;
    protected $enemybio;
    protected $enemyweakness;
    protected $enemyphoto;
    protected $cn;
    protected $db;
    protected $allroles;

    public function __construct($id = 0)
    {
        $this->db = new database();
        if ($id > 0) {
            $this->LoadProfile($id);
        }
    }
    public function __set($attribute, $value)
    {
        if (property_exists($this, $attribute)) {
            $this->$attribute = $value;
            echo "Updated {$attribute} to {$value}";
        } else {
            echo "Failed to update {$attribute}.";
        }
    }
    public function __get($name)
    {
        return $this->$name;
    }
    public function SaveProfile($enemyid, $enemytitle, $enemyfaction, $enemystrength, $enemypower, $enemybio, $enemyweakness, $enemyphoto, $mode)
   {
        $sql = "";

        if ($mode == "edit") {
            
            $sql = "update enemy set ";
            $sql .= "enemytitle = '" . $enemytitle . "',";
            $sql .= "enemyfaction = '" . $enemyfaction . "',";
            $sql .= "enemystrength = '" . $enemystrength . "',";
            $sql .= "enemypower = '" . $enemypower . "',";
            $sql .= "enemyweakness = '" . $enemyweakness . "',";
            $sql .= "enemybio = '" . addslashes($enemybio) . "',";
            $sql .= "enemyphoto = '" . $enemyphoto . "'";
            $sql .= " where enemyid = " . $enemyid;
            //echo "<pre>" . $sql . "</pre><br>";
        } else
        if ($mode == "new") {
            $sql = "insert into enemy(`enemyid`,`enemytitle`,`enemyfaction`,`enemystrength`,`enemypower`,`enemyweakness`,`enemybio`,`enemyphoto`) values(";
            $sql .= $enemyid . ",";
            $sql .= "'" . $enemytitle . "',";
            $sql .= "'" . $enemyfaction . "',";
            $sql .= "'" . $enemystrength . "',";
            $sql .= "'" . $enemypower . "',";

            $sql .= "'" . $enemyweakness . "',";
            $sql .= "'" . addslashes($enemybio) . "',";
            $sql .= "'" . $enemyphoto . "')";
        } else {
            return "Error: Invalid operation!";
        }


        $cn = $this->db->NewConnection();
        $result = $cn->query($sql);
        $msg = "Success: Saved the user enemy.";
        if ($result == false) {
            $msg = "Error: There was an error saving the enemy picture. " . $cn->errno . ": " . $cn->error .  $sql . "\n";
        }
        $this->db->CloseConnection();
        return $msg;
    }

    public function SaveProfilePicture($picture)
    {
        $sql = "";
        if ($picture != "") {
            $profileid = $this->enemy['enemyid'];
            $sql = "update enemy set ";
            $sql .= "picture = '" . $picture . "'";
            $sql .= " where enemyid = " . $profileid;
        } else {
            return "Error: Invalid operation!";
        }
        $cn = $this->db->NewConnection();
        $result = $cn->query($sql);
        $msg = "Success: Saved the enemy picture.";
        if ($result == false) {
            $msg = "Error: There was an error saving the enemy picture." . $cn->errno . ": " . $cn->error . "\n";
        }
        $this->db->CloseConnection();
        return $msg;
    }
    function LoadProfile($id)
    {
        $this->cn = $this->db->NewConnection();
        $sql = "Select * from enemy where enemyid=" . $id;
        $this->user =  $this->db->getArray($sql);
      

        $this->db->CloseConnection();
    }

    function RefreshProfile($id)
    {
        $this->cn = $this->db->NewConnection();
        $sql = "Select * from enemy where enemyid=" . $id;
        $this->enemy = $this->db->getArray($sql);
        $this->db->CloseConnection();
        return $this->enemy;
    }
}
