
<?php
require_once('database.php');
class ProfileDal
{
    protected $allies;
    protected $ally;
    protected $allyid;
    protected $allyname;
    protected $allyusername;
    protected $allyfaction;
    protected $allyhomeworld;
    protected $allybio;
    protected $allypower;
    protected $allyphoto;
    protected $cn;
    protected $db;
    protected $allroles;

    public function __construct($id = 0)
    {
        $this->db = new database();
        if ($id > 0) {
            $this->LoadProfile($id);
        }
    }
    public function __set($attribute, $value)
    {
        if (property_exists($this, $attribute)) {
            $this->$attribute = $value;
            echo "Updated {$attribute} to {$value}";
        } else {
            echo "Failed to update {$attribute}.";
        }
    }
    public function __get($name)
    {
        return $this->$name;
    }
    public function SaveProfile($allyid, $allyname, $allyusername, $allyfaction, $allyhomeworld, $allybio, $allypower, $allyphoto, $mode)

    {
        $sql = "";

        if ($mode == "edit") {
           
            $sql = "update allies set ";
            $sql .= "allyname = '" . $allyname . "',";
            $sql .= "allyusername = '" . $allyusername . "',";
            $sql .= "allyfaction = '" . $allyfaction . "',";
            $sql .= "allyhomeworld = '" . $allyhomeworld . "',";
            $sql .= "allybio = '" . addslashes($allybio) . "',";
            $sql .= "allypower = '" . $allypower . "',";
            $sql .= "allyphoto = '" . $allyphoto . "'";
            $sql .= " where allyid = ".  $allyid;
            //echo "<pre>" . $sql . "</pre><br>";
        } else
        if ($mode == "new") {
            $sql = "insert into allies(`allyid`,`allyname`,`allyusername`,`allyfaction`,`allyhomeworld`,`allybio`,`allypower`,`allyphoto`) values(";
            $sql .= $allyid . ",";
            $sql .= "'" . $allyname . "',";
            $sql .= "'" . $allyusername . "',";
            $sql .= "'" . $allyfaction . "',";
            $sql .= "'" . $allyhomeworld . "',";
            $sql .= "'" . addslashes($allybio) . "',";
            $sql .= "'" . $allypower . "',";
            $sql .= "'" . $allyphoto . "')";
        } else {
            return "Error: Invalid operation!";
        }


        $cn = $this->db->NewConnection();
        $result = $cn->query($sql);
        $msg = "Success: Saved the user profile.";
        if ($result == false) {
            $msg = "Error: There was an error saving the profile picture. " . $cn->errno . ": " . $cn->error .  $sql . "\n";
        }
        $this->db->CloseConnection();
        return $msg;
    }

    public function SaveProfilePicture($picture)
    {
        $sql = "";
        if ($picture != "") {
            $profileid = $this->profile['idprofile'];
            $sql = "update profile set ";
            $sql .= "picture = '" . $picture . "'";
            $sql .= " where idprofile = " . $profileid;
        } else {
            return "Error: Invalid operation!";
        }
        $cn = $this->db->NewConnection();
        $result = $cn->query($sql);
        $msg = "Success: Saved the profile picture.";
        if ($result == false) {
            $msg = "Error: There was an error saving the profile picture." . $cn->errno . ": " . $cn->error . "\n";
        }
        $this->db->CloseConnection();
        return $msg;
    }
    function LoadProfile($id)
    {
        $this->cn = $this->db->NewConnection();
        $sql = "Select * from allies where allyid=" . $id;
        $this->ally =  $this->db->getArray($sql);
   
        $this->db->CloseConnection();
    }

    function RefreshProfile($id)
    {
        $this->cn = $this->db->NewConnection();
        $sql = "Select * from allies where allyid=" . $id;
        $this->ally = $this->db->getArray($sql);
        $this->db->CloseConnection();
        return $this->ally;
    }
}
