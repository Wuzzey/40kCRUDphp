<?php
require_once('../config/databaseconfig.php');
class Database{
    protected $user = "root";
    protected $password = "1234";
    protected $db = "project";
    protected $config;
    protected $cn;
    public function __set($attribute, $value)
    {

        if (property_exists($this, $attribute)){
            $this->$attribute = $value;
            echo "Updated {$attribute} to {$value}";
        }
        else{
            echo "Failed to update {$attribute}.";
        }
    }
    public function __get($name){
        return $this->$name;

    }
    public function __construct()
    {
    }
    public function NewConnection()
    {
        $config = new configuration();
        $db = $config->database;
        $user = $config->dbuser;
        $pass = $config->dbpassword;
        $conn = new mysqli("localhost", $user, $pass, $db);
        if ($conn->connect_errno) {
            echo "Failed to connect to MySQL: " . $conn->connect_error;
            exit();
        }
        $this->cn = $conn;
        return $this->cn;
    }
    public function getAll($query){
        $cn = $this->cn;
        if($query==""){
            return "Error: query cannot be blank";
        }
        $result = $cn->query($query);
        $array = $result->fetch_all(MYSQLI_ASSOC);
        $result -> free_result();
        return $array;
    }
    public function getArray($query){
        $cn = $this->cn;
        if($query==""){
            return "Error: query cannot be blank";
        }
        $result = $cn->query($query);
        $array = $result->fetch_array(MYSQLI_ASSOC);
        $result -> free_result();
        return $array;
    }
    public function CloseConnection(){
        $this->cn->close();
    }
  
 


}



$db= new Database();
$cn=$db->NewConnection();
?>