
<?php
require_once('database.php');
class ProfileDal
{

    protected $item;
    protected $itemid;
    protected $itemname;
    protected $itemamount;
    protected $itemsummary;
    protected $itempower;
    protected $itemphoto;
    protected $cn;
    protected $db;
    protected $allroles;

    public function __construct($id = 0)
    {
        $this->db = new database();
        if ($id > 0) {
            $this->LoadProfile($id);
        }
    }
    public function __set($attribute, $value)
    {
        if (property_exists($this, $attribute)) {
            $this->$attribute = $value;
            echo "Updated {$attribute} to {$value}";
        } else {
            echo "Failed to update {$attribute}.";
        }
    }
    public function __get($name)
    {
        return $this->$name;
    }
    public function SaveProfile($itemid, $itemname, $itemtype, $itemamount, $itemsummary, $itempower, $itemphoto, $mode)

    {
        $sql = "";

        if ($mode == "edit") {
      
            $sql = "update inventory set ";
            $sql .= "itemname = '" . $itemname . "',";
            $sql .= "itemtype = '" . $itemtype . "',";
            $sql .= "itemamount = '" . $itemamount . "',";
            $sql .= "itemsummary = '" . addslashes($itemsummary) . "',";
            $sql .= "itempower = '" . $itempower . "',";
            $sql .= "itemphoto = '" . $itemphoto . "'";
     
            $sql .= " where itemid = " . $itemid;
            //echo "<pre>" . $sql . "</pre><br>";
        } else
        if ($mode == "new") {
            $sql = "insert into inventory(`itemid`,`itemname`,`itemtype`,`itemamount`,`itemsummary`,`itempower`,`itemphoto`) values(";
            $sql .= $itemid . ",";
            $sql .= "'" . $itemname . "',";
            $sql .= "'" . $itemtype . "',";
            $sql .= "'" . $itemamount . "',";
            $sql .= "'" . addslashes($itemsummary) . "',";
            $sql .= "'" . $itempower . "',";
            $sql .= "'" . $itemphoto . "')";
        } else {
            return "Error: Invalid operation!";
        }


        $cn = $this->db->NewConnection();
        $result = $cn->query($sql);
        $msg = "Success: Saved the user item.";
        if ($result == false) {
            $msg = "Error: There was an error saving the item picture. " . $cn->errno . ": " . $cn->error .  $sql . "\n";
        }
        $this->db->CloseConnection();
        return $msg;
    }

    public function SaveProfilePicture($picture)
    {
        $sql = "";
        if ($picture != "") {
            $profileid = $this->item['idprofile'];
            $sql = "update item set ";
            $sql .= "picture = '" . $picture . "'";
            $sql .= " where idprofile = " . $profileid;
        } else {
            return "Error: Invalid operation!";
        }
        $cn = $this->db->NewConnection();
        $result = $cn->query($sql);
        $msg = "Success: Saved the item picture.";
        if ($result == false) {
            $msg = "Error: There was an error saving the item picture." . $cn->errno . ": " . $cn->error . "\n";
        }
        $this->db->CloseConnection();
        return $msg;
    }
    function LoadProfile($id)
    {
        $this->cn = $this->db->NewConnection();
        $sql = "Select * from inventory where itemid=" . $id;
        $this->user =  $this->db->getArray($sql);

        $this->db->CloseConnection();
    }

    function RefreshProfile($id)
    {
        $this->cn = $this->db->NewConnection();
        $sql = "Select * from inventory where itemid=" . $id;
        $this->item = $this->db->getArray($sql);
        $this->db->CloseConnection();
        return $this->item;
    }
}
