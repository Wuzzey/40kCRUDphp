<?php
$local = true;
$root = $_SERVER["DOCUMENT_ROOT"] . "/website";

if ($local == false) {
    $root = $_SERVER["CONTEXT_DOCUMENT_ROOT"];
}

include($root . '/Projects/finalincludes/finalHeader.php');

?>

<div class='content'>
    <h2>Create Enemy</h2>
    <button onclick="window.location.href='Enemies.php';" style="float: right;">Back</button>
    <br>

    <form action="/page.php">


        Add Profile Image:
        <input type="file" name="fileToUpload" id="fileToUpload"></input>
        <br>
        <br>
        <label for="enemy">Choose a Enemy faction:</label>
        <select id="enemy" name="enemy">
            <option value="chaos">Chaos</option>
            <option value="necron">Necron</option>
            <option value="tau">Tau</option>
            <option value="orks">Orks</option>
            <option value="tyranids">Tyranids</option>
        </select>
        <br>
        <label for="Title">Title:</label>
        <input type="text" id="Title" name="Title"><br>
        <label for="strength">Choose a Strength:</label>
        <select id="strength" name="strength">
            <option value="none">none</option>
            <option value="fire">Fire</option>
        </select><br>
        <label for="weakness">Choose a Weakness:</label>
        <select id="weakness" name="weakness">
        <option value="none">none</option>
            <option value="fire">Fire</option>
        </select><br>

        <label for="description">Description:</label>
        <textarea name="description" for="description">Enter description here...</textarea>
        <br>

        <button type="submit">submit</button>
    </form>

</div>
<?php
include($root . '/Projects/finalincludes/finalFooter.php');
?>