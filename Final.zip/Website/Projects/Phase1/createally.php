<?php
//notes:
//https://www.w3schools.com/howto/tryit.asp?filename=tryhow_css_js_rangeslider
$local = true;
$root = $_SERVER["DOCUMENT_ROOT"] . "/website";

if ($local == false) {
    $root = $_SERVER["CONTEXT_DOCUMENT_ROOT"];
}

require($root . '/Projects/finalincludes/finalHeader.php');
require_once('../databaseinterface/database.php');
require_once('../databaseinterface/alliesdal.php');
$sqlally = "select * from allies";
$ally = $db->getAll($sqlally);
$allycounter = count($ally) + 1;
ob_start();


if (isset($_POST['save'])) {
    $p = new ProfileDal();

    //echo "Save button clicked!";
    extract($_POST, EXTR_PREFIX_SAME, "post");


    $result = $p->SaveProfile($allyid, $allyname, $allyusername, $allyfaction, $allyhomeworld, $allybio, $allypower, $allyphoto, 'new');

    $pos = strpos($result, "Error");
    $alert = "success";
    if ($pos > 0) {
        $alert = "Alarm";
    }
?>
    <div class="alert alert-<?= $alert ?> alert-dismissible fade in text-center" role="alert">
        <strong><?= $result ?></strong>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>

<?php

    echo $result . "<br>";
}


?>
<div class='content'>
    <h2>Create Ally</h2>

    <form method="post" enctype="multipart/form-data">
        <div class="card card-default">

            <div class="card-body">


                <div class="col">
                    <div class="form-group">
                        <input type="hidden" id="allyid" name="allyid" value="<?= $allycounter ?>">
                        <label for="allyname">Ally Name</label>
                        <input type="text" class="form-control" id="allyname" aria-describedby="FirstNameHelp" name="allyname" placeholder="Ally Name" value="">
                    </div>
                    <div class="form-group">
                        <label for="allyusername">Username</label>
                        <input type="text" class="form-control" id="allyusername" aria-describedby="LastNameHelp" Name="allyusername" placeholder="Username" value="">

                    </div>
                    <div class="form-group">
                        <label for="allyfaction">Faction</label>
                        <input type="text" class="form-control" id="allyfaction" aria-describedby="allyfaction" Name="allyfaction" placeholder="Faction" value="">

                    </div>
                    <div class="form-group">
                        <label for="allyhomeworld">Homeworld</label>
                        <input type="text" class="form-control" id="allyhomeworld" aria-describedby="DOBHelp" Name="allyhomeworld" Value="" placeholder="Homeworld" value="">

                    </div>
                    <div class="form-group">
                        <label for="allyphoto">photo</label>
                        <input type="text" class="form-control" id="allyphoto" aria-describedby="FirstNameHelp" name="allyphoto" placeholder="Ally Name" value="">
                    </div>



                    <p>Please set power level 1 - 100</p>
                    <input type="number" id="allypower" name="allypower" min="1" max="100">


                    <label for="allybio">Bio</label><br>
                    <textarea rows="5" cols="50" name="allybio"></textarea>



                    <div class="card-footer">
                        <input type="submit" name="save" class="btn btn-primary" id="savebutton" value="Save" />
                        <button type="button" class="btn btn-danger" id="cancelbutton">Cancel</button>
                    </div>
                </div>


    </form>




</div>
<?php
include($root . '/Projects/finalincludes/finalFooter.php');

?>
<script>
    $("#cancelbutton").click(() => {
        window.location = "Allies.php";
    });

    var slider = document.getElementById("allypower");
    var output = document.getElementById("demo");
    output.innerHTML = slider.value;

    slider.oninput = function() {
        output.innerHTML = this.value;
    }
</script>

<?php
