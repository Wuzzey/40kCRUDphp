<?php
$local = true;
$root = $_SERVER["DOCUMENT_ROOT"] . "/website";

if ($local == false) {
  $root = $_SERVER["CONTEXT_DOCUMENT_ROOT"];
}

require($root . '/Projects/finalincludes/finalHeader.php');
require_once('../databaseinterface/database.php');
$test;

$sql = "select * from battlereport";
$asql = "select * from allies";
$esql = "select * from enemy";
$isql = "select * from inventory";
$results = $db->getAll($sql);
$aresults = $db->getAll($asql);
$eresults = $db->getAll($esql);
$iresults = $db->getAll($isql);




@$id = $_REQUEST['id'];


ob_start();

if (isset($id)) {

  $viewprofile = $results[$id - 1];
  $aid = $viewprofile['allyid'];
  $eid = $viewprofile['enemyid'];

  $aviewprofile = $aresults[$aid - 1];
  $eviewprofile = $eresults[$eid - 1];





  if ($viewprofile['outcome'] == 1) {
    $winloss = $aviewprofile['allyname'] . " Win";
  } else {
    $winloss = $aviewprofile['allyname'] . " Lose";
  }


?>



  <div class='content'>
    <h2>Battle Report</h2>

    <div class="row">
      <div class="col">
        <div class="card card-default" style="min-width:400px">
          <div class="card-header">
            <div class='row'>

            </div>

          </div>
          <div class="card-body">
            <?php
            //echo "User ID: <label id='User Id'>" . $viewprofile['allyid'] . "</label>" . "<br/>"; 
            echo  $aviewprofile['allyname'];
            echo " VS " . $eviewprofile['enemyfaction'] . " " . $eviewprofile['enemytitle'] . "<br/>";
            echo "Outcome: " . $winloss . "<br/>";
            ?>
            </input>
            <br>
            <?php echo "<div> About: " . nl2br($viewprofile['battledetails'] . "</div>");
            ?>
          </div>
        </div>

      </div>
    </div>

    <table  class="table table-bordered table-hover">
      <thead class="thead-dark">
        <tr>
          <th>Battle Id</th>
          <th>Ally</th>
          <th>Number of allies</th>
          <th>Item</th>
          <th>Enemy</th>
          <th>Number of enemies</th>
          <th>Outcome</th>
          <th>Date</th>
          <th><button id="createnew">Create New Battle</button></th>
        </tr>

      </thead>
      <tbody id="allies">

        <?php


        foreach ($results as $r) {

          $aselected = $r['allyid'];
          $eselected = $r['enemyid'];
          $iselected = $r['itemid'];
          $a = $aresults[$aselected - 1];
          $e = $eresults[$eselected - 1];
          $i = $iresults[$iselected - 1];


          if ($r['outcome'] == 0001) {
            $outcome = 'Win';
          } else {
            $outcome = 'Loss';
          }
          echo "<tr>";
          echo "<td><span id='id'>" . $r['battlereportid'] . "</span></td>";
          // echo "<td><img class='ProfileImage' src='../../profile/pictures/" . $r['picture']."'.alt='".$r['picture'] ."'/></td>";
          echo "<td>" . $a['allyname'] . "</td>";
          echo "<td>" . $r['numberofally'] . "</td>";
          echo "<td>" . $i['itemname'] . "</td>";
          echo "<td>" . $e['enemyfaction'] . " " . $e['enemytitle'] . "</td>";
          echo "<td>" . $r['numberofenemy'] . "</td>";
          echo "<td>" . $outcome . "</td>";
          echo "<td>" . $r['battledate'] . "</td>";
          echo "</tr>";
        }
        ?>

      </tbody>
    </table>


  </div>



  <script>
    $("#allies tr").on('click', function() {
      var currentRow = $(this).closest("tr");
      var id = currentRow.find("td span").text();
      window.location = "/website/Projects/Phase1/BattleReport.php?id=" + id;

    });
  </script>
   <script>
     $("#createnew").on('click', function() {
       window.location = "/website/Projects/Phase1/createbattle.php";
     });
   </script>
<?php
  include($root . '/Projects/finalincludes/finalFooter.php');
} else {
?>
  <div class='content'>
    <h2>Battle Report</h2>


    <table class="table table-bordered table-hover">
      <thead class="thead-dark">
        <tr>
          <th>Battle Id</th>
          <th>Ally</th>
          <th>Number of allies</th>
          <th>Item</th>
          <th>Enemy</th>
          <th>Number of enemies</th>
          <th>Outcome</th>
          <th>Date</th>
          <th><button id="createnew">Create New Battle</button></th>
        </tr>

      </thead>
      <tbody id="allies">

        <?php


        foreach ($results as $r) {

          $aselected = $r['allyid'];
          $eselected = $r['enemyid'];
          $iselected = $r['itemid'];
          $a = $aresults[$aselected - 1];
          $e = $eresults[$eselected - 1];
          $i = $iresults[$iselected - 1];


          if ($r['outcome'] == 1) {
            $outcome = 'Win';
          } else {
            $outcome = 'Loss';
          }
          echo "<tr>";
          echo "<td><span id='id'>" . $r['battlereportid'] . "</span></td>";
          // echo "<td><img class='ProfileImage' src='../../profile/pictures/" . $r['picture']."'.alt='".$r['picture'] ."'/></td>";
          echo "<td>" . $a['allyname'] . "</td>";
          echo "<td>" . $r['numberofally'] . "</td>";
          echo "<td>" . $i['itemname'] . "</td>";
          echo "<td>" . $e['enemyfaction'] . " " . $e['enemytitle'] . "</td>";
          echo "<td>" . $r['numberofenemy'] . "</td>";
          echo "<td>" . $outcome . "</td>";
          echo "<td>" . $r['battledate'] . "</td>";
          echo "</tr>";
        }
        ?>

      </tbody>
    </table>


  </div>



  <script>
    $("#allies tr").on('click', function() {
      var currentRow = $(this).closest("tr");
      var id = currentRow.find("td span").text();
      window.location = "/website/Projects/Phase1/BattleReport.php?id=" + id;

    });
  </script>
   <script>
     $("#createnew").on('click', function() {
       window.location = "/website/Projects/Phase1/createbattle.php";
     });
   </script>
<?php
  include($root . '/Projects/finalincludes/finalFooter.php');
}
?>