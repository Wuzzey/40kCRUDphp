<?php
//notes:
//https://www.w3schools.com/howto/tryit.asp?filename=tryhow_css_js_rangeslider
$local = true;
$root = $_SERVER["DOCUMENT_ROOT"] . "/website";
@$id = $_GET['id'];


if ($local == false) {
    $root = $_SERVER["CONTEXT_DOCUMENT_ROOT"];
}

require($root . '/Projects/finalincludes/finalHeader.php');
require_once('../databaseinterface/database.php');
require_once('../databaseinterface/enemydal.php');
$sqlally = "select * from enemy";

ob_start();
if (isset($id)) {
    $p = new ProfileDal($id);
    $enemy = $p->enemy;

    if (isset($_POST['save'])) {


        //echo "Save button clicked!";
        extract($_POST, EXTR_PREFIX_SAME, "post");


        $result = $p->SaveProfile($enemyid, $enemytitle, $enemyfaction, $enemystrength, $enemypower, $enemybio, $enemyweakness, $enemyphoto, 'edit');
        

        $pos = strpos($result, "Error");
        $alert = "success";
        if ($pos > 0) {
            $alert = "Alarm";
        }
?>
        <div class="alert alert-<?= $alert ?> alert-dismissible fade in text-center" role="alert">
            <strong><?= $result ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>

<?php

        echo $result . "<br>";
    }
}

$enemy = $p->RefreshProfile($id);
?>
<div class='content'>
    <h2>Edit Enemy</h2>

    <form method="post" enctype="multipart/form-data">
        <div class="card card-default">

            <div class="card-body">


                <div class="col">
                    <div class="form-group">
                        <input type="hidden" id="enemyid" name="enemyid" value="<?= $enemy['enemyid'] ?>">
                    </div>

                    <div class="form-group">
                        <label for="enemytitle">Title</label>
                        <input type="text" class="form-control" id="enemytitle" aria-describedby="LastNameHelp" Name="enemytitle" placeholder="Title" value="<?= $enemy['enemytitle'] ?>">

                    </div>
                    <div class="form-group">
                        <label for="enemyfaction">Faction</label>
                        <input type="text" class="form-control" id="enemyfaction" aria-describedby="enemyfaction" Name="enemyfaction" placeholder="Faction" value="<?= $enemy['enemyfaction'] ?>">

                    </div>

                    <div class="form-group">
                        <label for="enemystrength">Strength</label>
                        <input list="enemystrength" name="enemystrength" value="<?= $enemy['enemystrength'] ?>" >
                        <datalist id="enemystrength" >
                            <option value="None">
                            <option value="light explosive">
                            <option value="heavy explosive">
                            <option value="light flame">
                            <option value="heavy flame">
                            <option value="light laser">
                            <option value="heavy laser">
                            <option value="light plasma">
                            <option value="heavy plasma">
                            <option value="light vehicle">
                            <option value="heavy vehicle">
                            <option value="titanic">
                            <option value="grenade">
                            <option value="light melee">
                            <option value="heavy melee">

                        </datalist>
                    </div>


                    <div class="form-group">
                        <label for="enemyweakness">Weakness</label>
                        <input list="enemyweakness" name="enemyweakness" value="<?= $enemy['enemyweakness'] ?>">
                        <datalist id="enemyweakness">
                            <option value="None">
                            <option value="light explosive">
                            <option value="heavy explosive">
                            <option value="light flame">
                            <option value="heavy flame">
                            <option value="light laser">
                            <option value="heavy laser">
                            <option value="light plasma">
                            <option value="heavy plasma">
                            <option value="light vehicle">
                            <option value="heavy vehicle">
                            <option value="titanic">
                            <option value="grenade">
                            <option value="light melee">
                            <option value="heavy melee">

                        </datalist>
                    </div>

                    <div class="form-group">
                        <label for="enemyphoto">Photo</label>
                        <input type="text" class="form-control" id="enemyphoto" aria-describedby="FirstNameHelp" name="enemyphoto" placeholder="enemy photo" value="<?= $enemy['enemyphoto'] ?>">
                    </div>





                    <p>Please set power level 1 - 100</p>
                    <input type="number" id="enemypower" name="enemypower" min="1" max="100" value="<?= $enemy['enemypower'] ?>">


                    <label for="enemybio">Bio</label><br>
                    <textarea rows="5" cols="50" name="enemybio"><?php echo $enemy['enemybio'];?></textarea>



                    <div class="card-footer">
                        <input type="submit" name="save" class="btn btn-primary" id="savebutton" value="Save" />
                        <button type="button" class="btn btn-danger" id="cancelbutton">Cancel</button>
                    </div>
                </div>


    </form>




</div>
<?php
include($root . '/Projects/finalincludes/finalFooter.php');

?>
<script>
    $("#cancelbutton").click(() => {
        window.location = "Enemies.php";
    });

    $("#savebutton").click(() => {
        
        window.location = "Enemies.php";
        
    });
</script>

<?php
