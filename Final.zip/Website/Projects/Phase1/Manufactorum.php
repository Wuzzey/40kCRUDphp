<?php
$local = true;
$root = $_SERVER["DOCUMENT_ROOT"] . "/website";

if ($local == false) {
  $root = $_SERVER["CONTEXT_DOCUMENT_ROOT"];
}

require($root . '/Projects/finalincludes/finalHeader.php');
require_once('../databaseinterface/database.php');

$sql = "select * from inventory";
$results = $db->getAll($sql);
@$id = $_REQUEST['id'];

ob_start();

if (isset($id)) {
  $viewprofile = $results[$id - 1];

?>



  <div class='content'>
    <h2>Manufactorum</h2>

    <div class="row">
      <div class="col">
        <div class="card card-default" style="min-width:400px">
          <div class="card-header">
            <div class='row'>
            <button id='Edit' class="bigbutton">Edit</button>
            </div>

          </div>


          <div class="card-body">
            <p>
              <img class="mainProfile" style="width:300px; float: left;" src="../finalimages/<?= $viewprofile['itemphoto'] ?>" alt='Profilepicture'>
            </p>
            <?php
            echo "Item ID: <label id='itemId'>" . $viewprofile['itemid'] . "</label>" . "<br/>"; 
            echo "Item Name:  " . $viewprofile['itemname'] . "<br/>";
            echo "Type: " . $viewprofile['itemtype'] . "<br/>";
            echo "Item amount: " . $viewprofile['itemamount'] . "<br/>";
            echo "Power level: " . $viewprofile['itempower'] . "<br/>";


            ?>
            </input>
            <br><br>
            <?php echo "<div> Decription: " . nl2br($viewprofile['itemsummary'] . "</div>");
            ?>
          </div>
        </div>

      </div>
    </div>

    <table class="table table-bordered table-hover">
      <thead class="thead-dark">
        <tr>
          <th>ID</th>
          <th>Item Name</th>
          <th>Item Type</th>
          <th>Amount</th>
          <th>Power level</th>
          <th><button id="createnew">Create New Item</button></th>
        </tr>

      </thead>
      <tbody id="allies">

        <?php


        foreach ($results as $r) {
          echo "<tr>";
          echo "<td><span id='id'>" . $r['itemid'] . "</span></td>";
          // echo "<td><img class='ProfileImage' src='../../profile/pictures/" . $r['picture']."'.alt='".$r['picture'] ."'/></td>";
          echo "<td>" . $r['itemname'] . "</td>";
          echo "<td>" . $r['itemtype'] . "</td>";
          echo "<td>" . $r['itemamount'] . "</td>";
          echo "<td>" . $r['itempower'] . "</td>";
          echo "</tr>";
        }
        ?>

      </tbody>
    </table>


  </div>



  <script>
     $("#Edit").on('click', function() {
    //https://stackoverflow.com/questions/31007427/javascript-get-inner-html-text-for-span-by-class-name/31007547

       var id = $("#itemId").text();
      window.location = "/website/Projects/Phase1/edititem.php?id=" + id;
     });
   </script>
  <script>
    $("#allies tr").on('click', function() {
      var currentRow = $(this).closest("tr");
      var id = currentRow.find("td span").text();
      window.location = "/website/Projects/Phase1/Manufactorum.php?id=" + id;

    });
  </script>
  <script>
    $("#createnew").on('click', function() {
      window.location = "/website/Projects/Phase1/createitem.php";
    });
  </script>

<?php
  include($root . '/Projects/finalincludes/finalFooter.php');
} else {
?>
  <div class='content'>
    <h2>Manufactorum</h2>


    <table class="table table-bordered table-hover">
      <thead class="thead-dark">
        <tr>
          <th>ID</th>
          <th>Item Name</th>
          <th>Item Type</th>
          <th>Amount</th>
          <th>Power level</th>
          <th><button id="createnew">Create New Item</button></th>
        </tr>

      </thead>
      <tbody id="allies">

        <?php



        foreach ($results as $r) {
          echo "<tr>";
          echo "<td><span id='id'>" . $r['itemid'] . "</span></td>";
          // echo "<td><img class='ProfileImage' src='../../profile/pictures/" . $r['picture']."'.alt='".$r['picture'] ."'/></td>";
          echo "<td>" . $r['itemname'] . "</td>";
          echo "<td>" . $r['itemtype'] . "</td>";
          echo "<td>" . $r['itemamount'] . "</td>";
          echo "<td>" . $r['itempower'] . "</td>";
          echo "</tr>";
        }
        ?>

      </tbody>
    </table>


  </div>



  <script>
    $("#allies tr").on('click', function() {
      var currentRow = $(this).closest("tr");
      var id = currentRow.find("td span").text();
      window.location = "/website/Projects/Phase1/Manufactorum.php?id=" + id;

    });
  </script>
  <script>
    $("#createnew").on('click', function() {
      window.location = "/website/Projects/Phase1/createitem.php";
    });
  </script>
<?php
  include($root . '/Projects/finalincludes/finalFooter.php');
}
?>