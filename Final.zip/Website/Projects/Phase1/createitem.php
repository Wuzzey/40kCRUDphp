<?php
//notes:
//https://www.w3schools.com/howto/tryit.asp?filename=tryhow_css_js_rangeslider
$local = true;
$root = $_SERVER["DOCUMENT_ROOT"] . "/website";

if ($local == false) {
    $root = $_SERVER["CONTEXT_DOCUMENT_ROOT"];
}

require($root . '/Projects/finalincludes/finalHeader.php');
require_once('../databaseinterface/database.php');
require_once('../databaseinterface/manufactorumdal.php');
$sqlally = "select * from inventory";
$ally = $db->getAll($sqlally);
$allycounter = count($ally) + 1;
ob_start();


if (isset($_POST['save'])) {
    $p = new ProfileDal();

    //echo "Save button clicked!";
    extract($_POST, EXTR_PREFIX_SAME, "post");


    $result = $p->SaveProfile($itemid, $itemname, $itemtype, $itemamount,  $itemsummary, $itempower, $itemphoto, 'new');

    $pos = strpos($result, "Error");
    $alert = "success";
    if ($pos > 0) {
        $alert = "Alarm";
    }
?>
    <div class="alert alert-<?= $alert ?> alert-dismissible fade in text-center" role="alert">
        <strong><?= $result ?></strong>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>

<?php

    echo $result . "<br>";
}


?>
<div class='content'>
    <h2>Create Item</h2>

    <form method="post" enctype="multipart/form-data">
        <div class="card card-default">

            <div class="card-body">


                <div class="col">
                    <div class="form-group">
                        <input type="hidden" id="itemid" name="itemid" value="<?= $allycounter ?>">
                        <label for="itemname">Item Name</label>
                        <input type="text" class="form-control" id="itemname" aria-describedby="FirstNameHelp" name="itemname" placeholder="Item Name" value="">
                    </div>
                    <div class="form-group">
                        <p>Stock 1-9999999</p>
                        <input type="number" id="itemamount" name="itemamount" min="1" max="9999999">

                    </div>






                    <div class="form-group">
                        <label for="itemtype">Type</label>
                        <input list="itemtype" name="itemtype">
                        <datalist id="itemtype">
                            <option value="light explosive">
                            <option value="heavy explosive">
                            <option value="light flame">
                            <option value="heavy flame">
                            <option value="light laser">
                            <option value="heavy laser">
                            <option value="light plasma">
                            <option value="heavy plasma">
                            <option value="light vehicle">
                            <option value="heavy vehicle">
                            <option value="titanic">
                            <option value="grenade">
                            <option value="light melee">
                            <option value="heavy melee">
                        </datalist>
                    </div>


                    <div class="form-group">
                        <label for="itemphoto">Photo</label>
                        <input type="text" class="form-control" id="itemphoto" aria-describedby="itemphoto" Name="itemphoto" placeholder="Photo" value="">

                    </div>

                    <p>Please set power level 1 - 100</p>
                    <input type="number" id="itempower" name="itempower" min="1" max="100">


                    <label for="itemsummary">Description</label><br>
                    <textarea rows="5" cols="50" name="itemsummary"></textarea>



                    <div class="card-footer">
                        <input type="submit" name="save" class="btn btn-primary" id="savebutton" value="Save" />
                        <button type="button" class="btn btn-danger" id="cancelbutton">Cancel</button>
                    </div>
                </div>


    </form>




</div>
<?php
include($root . '/Projects/finalincludes/finalFooter.php');

?>
<script>
    $("#cancelbutton").click(() => {
        window.location = "Manufactorum.php";
    });

    var slider = document.getElementById("itempower");
    var output = document.getElementById("demo");
    output.innerHTML = slider.value;

    slider.oninput = function() {
        output.innerHTML = this.value;
    }
</script>
