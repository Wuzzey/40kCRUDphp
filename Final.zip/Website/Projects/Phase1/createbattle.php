<?php
//notes:
//https://www.w3schools.com/howto/tryit.asp?filename=tryhow_css_js_rangeslider
$local = true;
$root = $_SERVER["DOCUMENT_ROOT"] . "/website";

if ($local == false) {
    $root = $_SERVER["CONTEXT_DOCUMENT_ROOT"];
}

require($root . '/Projects/finalincludes/finalHeader.php');
require_once('../databaseinterface/database.php');
require_once('../databaseinterface/alliesdal.php');
$sqlally = "select * from battlereport";
$asql = "select * from allies";
$esql = "select * from enemy";
$isql = "select * from inventory";
$aresults = $db->getAll($asql);
$eresults = $db->getAll($esql);
$iresults = $db->getAll($isql);



$ally = $db->getAll($sqlally);
$allycounter = count($ally) + 1;
ob_start();


/*if (isset($_POST['sim'])) {
    
    extract($_POST, EXTR_PREFIX_SAME, "post");
    $allyvalue = $allyname; 
    $enemyvalue = $enemyname; 
    $allymulti = $numberofally; 
    $enemymulti = $numberofenemy; 
    $itemaddition = $itemname; 
  
    $allytotal = ($allyvalue * $allymulti) + $itemaddition;
    $enemytotal = $enemyvalue * $enemymulti;
    if ($allytotal > $enemytotal){
        echo "Allies Win!";
    }
    if ($allytotal < $enemytotal){
        echo "Allies Lose!";
    }
    if ($allytotal = $enemytotal){
       echo "Tie!";
    }
    

}*/
if (isset($_POST['save'])) {
    $p = new ProfileDal();

    //echo "Save button clicked!";
    extract($_POST, EXTR_PREFIX_SAME, "post");


    $result = $p->SaveProfile($battlereportid, $allyid, $itemid, $enemyid, $outcome, $battledetails, $battledate, $numberofenemy, $numberofally,'new');

    $pos = strpos($result, "Error");
    $alert = "success";
    if ($pos > 0) {
        $alert = "Alarm";
    }
?>
    <div class="alert alert-<?= $alert ?> alert-dismissible fade in text-center" role="alert">
        <strong><?= $result ?></strong>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>

<?php

    echo $result . "<br>";
}


?>
<div class='content'>
    <h2>Create Battle</h2>

    <form method="post" enctype="multipart/form-data">
        <div class="card card-default">

            <div class="card-body">



                <div class="col">
                <label for="Simorreal">Check box if this is a real battle to be logged:</label> 
                <input type="checkbox" id="myCheck" onclick="sim()">

                <div class="form-group">
                        <input type="hidden" id="battlereportid" name="battlereportid" value="<?= $allycounter ?>">

                    </div>
                    <div class="form-group">
                        <label for="allyname">Ally Name</label>
                        <select id="allyname" style="width:150px;">
                            <?php
                        foreach ($aresults as $r) {
                          echo "<option value=" . $r['allyid'] .">" . $r['allyname']. "</option>";
                        }
                          ?>                
                        </select>
                    </div>
                     <div class="form-group">
                        <label for="itemname">Item Name</label>
                        <select id="itemname" style="width:150px;">
                            <?php
                        foreach ($iresults as $r) {
                          echo "<option value=" . $r['itemid'] .">" . $r['itemname']. "</option>";
                        }
                          ?>                
                        </select>
                    </div>
                      <div class="form-group">
                        <label for="enemyname">Enemy Name</label>
                        <select id="enemyname" style="width:150px;">
                            <?php
                        foreach ($eresults as $r) {
                          echo "<option value=" . $r['enemyid']  .">" . $r['enemyfaction']  . " ". $r['enemytitle'] . "</option>";
                        }
                          ?>                
                        </select>
                   
                    </div>
                    <div class="form-group">
                        <label for="numberofally">Number of Ally</label>
                        <input type="number" id="numberofally" name="numberofally" min="1" max="1000">
                     </div>

                    <div class="form-group">
                        <label for="numberofenemy">Number of Enemy</label>
                        <input type="number" id="numberofenemy" name="numberofenemy" min="1" max="1000">
                     </div>
                 
                     <div id= "Onlyreal" style="display:none" class="form-group">
                            <label for="battledate">Battle Date</label>
                        <input type="date" id="battledate" name="battledate" >
                    </div>

                    <div id= "Onlyreal2" style="display:none" class="form-group">
                            <label  for="battledetails">Battle Details</label><br>
                            <textarea  rows="5" cols="50" name="battledetails"></textarea>
                    </div>

                    <div id= "Onlyreal3" style="display:none" class="form-group">
                        <label for="outcome">Outcome</label>
                        <input list="outcome" name="outcome">
                        <datalist id="outcome">
                            <option value="Win">
                            <option value="Loss">
                        </datalist>
                    </div>
                    <div id="sim" style="display:inline" class="card-footer">
                        
                        <button type="sim" name="sim" class="btn btn-primary" id="simbutton">Sim</button>
                       
                    </div>
               
                    <div id="save" style="display:none" class="card-footer">
                        
                        <input type="submit" name="save" class="btn btn-primary" id="savebutton" value="Save" />
                        <button type="button" class="btn btn-danger" id="cancelbutton">Cancel</button>
                       
                    </div>
                   
                </div>


    </form>




</div>
<?php
include($root . '/Projects/finalincludes/finalFooter.php');

?>
<script>
    $("#cancelbutton").click(() => {
        window.location = "Battlereport.php";
    });


    $("#simbutton").click(() => {
      //  var slider = "Allies Win!\n";
        //alert("Hello! I am an alert box!!");
       /* var allyvalue = ""; 
        var enemyvalue = ""; 
        var allymulti = ""; 
        var enemymulti = ""; 
        var itemaddition = ""; 
        var enemyresistance = ""; 
        var enemyweakness = ""; 
        if (enemyresistance==true){
            itemaddition = 0;
        }
        if (enemyweakness==true){
            itemaddition = itemaddition * 2;
        }
        var allytotal = (allyvalue * allymulti) + itemaddition;
        var enemytotal = enemyvalue * enemymulti;
        if (allytotal > enemytotal){
            alert("Allies Win!");
        }
        if (allytotal < enemytotal){
            alert("Allies Lose!");
        }
        if (allytotal = enemytotal){
            alert("Tie!");
        }*/


    });



    var slider = document.getElementById("battledate");
    var output = document.getElementById("demo");
    output.innerHTML = slider.value;

    slider.oninput = function() {
        output.innerHTML = this.value;
    };
</script>
<script>
function sim(){
  var checkBox = document.getElementById("myCheck");
  var text = document.getElementById("Onlyreal");
  if (checkBox.checked == true){
    text.style.display = "block";
  } else {
     text.style.display = "none";
  }
  var text = document.getElementById("Onlyreal2");
  if (checkBox.checked == true){
    text.style.display = "block";
  } else {
     text.style.display = "none";
  }
  var text = document.getElementById("Onlyreal3");
  if (checkBox.checked == true){
    text.style.display = "block";
  } else {
     text.style.display = "none";
  }
  var text = document.getElementById("save");
  if (checkBox.checked == true){
    text.style.display = "inline";
  } else {
     text.style.display = "none";
  }
 
  var text1 = document.getElementById("sim");
  if (checkBox.checked == true){
    text1.style.display = "none";
  } else {
    text1.style.display = "inline";
  }
}
</script>