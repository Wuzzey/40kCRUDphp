<?php
$local = true;
$root = $_SERVER["DOCUMENT_ROOT"] . "/website";

if ($local == false) {
  $root = $_SERVER["CONTEXT_DOCUMENT_ROOT"];
}

require($root . '/Projects/finalincludes/finalHeader.php');
require_once('../databaseinterface/database.php');

$sql = "select * from enemy";
$results = $db->getAll($sql);
@$id = $_REQUEST['id'];

ob_start();

if (isset($id)) {
  $viewprofile = $results[$id - 1];

?>



  <div class='content'>
    <h2>Enemies</h2>

    <div class="row">
      <div class="col">
        <div class="card card-default" style="min-width:400px">
          <div class="card-header">
            <div class='row'>
            <button id='Edit' class="bigbutton">Edit</button>
            </div>

          </div>

          <div class="card-body">
            <p>
              <img class="mainProfile" style="width:300px; float: left;" src="../finalimages/<?= $viewprofile['enemyphoto'] ?>" alt='Profilepicture'>
            </p>
            <?php
            echo "Enemy ID: <label id='enemyId'>" . $viewprofile['enemyid'] . "</label>" . "<br/>"; 
            echo "Faction:  " . $viewprofile['enemyfaction'] . "<br/>";
            echo "Name: " . $viewprofile['enemytitle'] . "<br/>";
            echo "Power Level: " . $viewprofile['enemypower'] . "<br/>";
            echo "Weakness: " . $viewprofile['enemyweakness'] . "<br/>";
            echo "Resistance: " . $viewprofile['enemystrength'] . "<br/>";

            ?>
            </input>
            <br><br>
            <?php echo "<div> About: " . nl2br($viewprofile['enemybio'] . "</div>");
            ?>
          </div>
        </div>

      </div>
    </div>

    <table class="table table-bordered table-hover">
      <thead class="thead-dark">
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Faction</th>
          <th>Power</th>
          <th>Strength</th>
          <th>Resistance</th>
          <th><button id="createnew">Create New Enemy</button></th>

        </tr>

      </thead>
      <tbody id="allies">

        <?php


        foreach ($results as $r) {
          echo "<tr>";
          echo "<td><span id='id'>" . $r['enemyid'] . "</span></td>";
          // echo "<td><img class='ProfileImage' src='../../profile/pictures/" . $r['picture']."'.alt='".$r['picture'] ."'/></td>";
          echo "<td>" . $r['enemytitle'] . "</td>";
          echo "<td>" . $r['enemyfaction'] . "</td>";
          echo "<td>" . $r['enemypower'] . "</td>";
          echo "<td>" . $r['enemystrength'] . "</td>";
          echo "<td>" . $r['enemyweakness'] . "</td>";
          echo "</tr>";
        }
        ?>

      </tbody>
    </table>


  </div>


  <script>
     $("#Edit").on('click', function() {
    //https://stackoverflow.com/questions/31007427/javascript-get-inner-html-text-for-span-by-class-name/31007547

       var id = $("#enemyId").text();
      window.location = "/website/Projects/Phase1/editenemy.php?id=" + id;
     });
   </script>
  <script>
    $("#allies tr").on('click', function() {
      var currentRow = $(this).closest("tr");
      var id = currentRow.find("td span").text();
      window.location = "/website/Projects/Phase1/Enemies.php?id=" + id;

    });
  </script>
  <script>
    $("#createnew").on('click', function() {
      window.location = "/website/Projects/Phase1/createenemy.php";
    });
  </script>
<?php
  include($root . '/Projects/finalincludes/finalFooter.php');
} else {
?>
  <div class='content'>
    <h2>Enemies</h2>


    <table class="table table-bordered table-hover">
      <thead class="thead-dark">
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Faction</th>
          <th>Power</th>
          <th>Strength</th>
          <th>Resistance</th>
          <th><button id="createnew">Create New Enemy</button></th>

        </tr>

      </thead>
      <tbody id="allies">

        <?php


        foreach ($results as $r) {
          echo "<tr>";
          echo "<td><span id='id'>" . $r['enemyid'] . "</span></td>";
          // echo "<td><img class='ProfileImage' src='../../profile/pictures/" . $r['picture']."'.alt='".$r['picture'] ."'/></td>";
          echo "<td>" . $r['enemytitle'] . "</td>";
          echo "<td>" . $r['enemyfaction'] . "</td>";
          echo "<td>" . $r['enemypower'] . "</td>";
          echo "<td>" . $r['enemystrength'] . "</td>";
          echo "<td>" . $r['enemyweakness'] . "</td>";
          echo "</tr>";
        }
        ?>

      </tbody>
    </table>


  </div>



  <script>
    $("#allies tr").on('click', function() {
      var currentRow = $(this).closest("tr");
      var id = currentRow.find("td span").text();
      window.location = "/website/Projects/Phase1/Enemies.php?id=" + id;

    });
  </script>
  <script>
    $("#createnew").on('click', function() {
      window.location = "/website/Projects/Phase1/createenemy.php";
    });
  </script>
<?php
  include($root . '/Projects/finalincludes/finalFooter.php');
}
?>