<?php
$local = true;
$root = $_SERVER["DOCUMENT_ROOT"] ."/website";

if ($local == false) {
    $root = $_SERVER["CONTEXT_DOCUMENT_ROOT"];
}

include($root .'/Projects/finalincludes/finalHeader.php');
?>

<form action="/action_page.php" method="post">
  
  <div class="logpage">
    <h3 style="color:white;">Please Enter Your Credentials</h3>
    <br>
    <label for="uname"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="uname" required>  n 

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" required>
        
    <button type="submit">Login</button>
 
  </div>


</form>


<?php
include($root . '/Projects/finalincludes/finalFooter.php');
?>
