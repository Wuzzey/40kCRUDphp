<?php
$local = true;
$root = $_SERVER["DOCUMENT_ROOT"] . "/website";

if ($local == false) {
    $root = $_SERVER["CONTEXT_DOCUMENT_ROOT"];
}

include($root . '/Projects/finalincludes/finalHeader.php');

?>

<div class='content'>
    <h2>Create Inventory</h2>
    <button onclick="window.location.href='Manufactorum.php';" style="float: right;">Back</button>
    <br>

    <form action="/page.php">


        Add Image:
        <input type="file" name="fileToUpload" id="fileToUpload"></input>
        <br>
        <br>

        <label for="name">Name:</label>
        <input type="text" id="name" name="name"><br>

        <label for="type">Choose a type:</label>
        <select id="type" name="type">
            <option value="weapon">Weapon</option>
            <option value="grenade">Grenade</option>
            <option value="vehicle">Vehicle</option>
            <option value="transport">Transport</option>
        </select><br>
        
        <label for="stock">Amount in Stock:</label>
        <input type="text" id="stock" name="stock"><br>


        <label for="strength">Choose a Strength:</label>
        <select id="strength" name="strength">
            <option value="none">none</option>
            <option value="fire">Fire</option>
        </select><br>

        <label for="description">Description:</label>
        <textarea name="description" for="description">Enter description here...</textarea>
        <br>

        <button type="submit">submit</button>
    </form>

</div>
<?php
include($root . '/Projects/finalincludes/finalFooter.php');
?>