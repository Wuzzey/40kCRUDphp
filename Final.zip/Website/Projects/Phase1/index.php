<?php
$local = true;
$root = $_SERVER["DOCUMENT_ROOT"] . "/website";

if ($local == false) {
    $root = $_SERVER["CONTEXT_DOCUMENT_ROOT"];
}

include($root . '/Projects/finalincludes/finalHeader.php');

?>

<body>

    <div class="content">
        <h2>Home</h2>

        <h2 style="text-align: center; padding-top: 200px; background-color: transparent;"> <h2>
    </div>

</body>
<?php
include($root . '/Projects/finalincludes/finalFooter.php');
?>