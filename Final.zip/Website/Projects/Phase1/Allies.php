 <?php
 //for button stuff
 //https://www.w3schools.com/howto/howto_css_block_buttons.asp

  $local = true;
  $root = $_SERVER["DOCUMENT_ROOT"] . "/website";

  if ($local == false) {
    $root = $_SERVER["CONTEXT_DOCUMENT_ROOT"];
  }

  require($root . '/Projects/finalincludes/finalHeader.php');
  require_once('../databaseinterface/database.php');

  $sql = "select * from allies";
  $results = $db->getAll($sql);
  @$id = $_REQUEST['id'];

  ob_start();

  if (isset($id)) {
    $viewprofile = $results[$id - 1];

  ?>



   <div class='content'>
     <h2>Allies</h2>

     <div class="row">
       <div class="col">
         <div class="card card-default" style="min-width:400px">
           <div class="card-header">
             <div class='row'>
             <button id='Edit' class="bigbutton">Edit</button>
             </div>

           </div>
           <div class="card-body">
         
             <p>
               <img class="mainProfile" style="width:300px; float: left;" src="../finalimages/<?= $viewprofile['allyphoto'] ?>" alt='Profilepicture'>
             </p>
             <?php
              echo "Ally ID: <label id='UserId'>" . $viewprofile['allyid'] . "</label>" . "<br/>"; 
              echo "Name:  " . $viewprofile['allyname'] . "<br/>";
              echo "Faction: " . $viewprofile['allyfaction'] . "<br/>";
              echo "Homeworld: " . $viewprofile['allyhomeworld'] . "<br/>";
              echo "Power Level: " . $viewprofile['allypower'] . "<br/>";
              echo "Username: " . $viewprofile['allyusername'] . "<br/>";
              
              ?>
             </input>
             <br><br>
             <?php echo "<div> About: " . nl2br($viewprofile['allybio'] . "</div>");
              ?>

          
           </div>
         </div>
         
       </div>
     </div>

     <table class="table table-bordered table-hover">
       <thead class="thead-dark">
         <tr>
           <th>ID</th>
           <th>Name</th>
           <th>Faction</th>
           <th>Homeworld</th>
           <th>Power</th>
           <th>Username</th>

           <th><button id="createnew">Create New Ally</button></th>
         </tr>

       </thead>
       <tbody id="allies">

         <?php


          foreach ($results as $r) {
            echo "<tr>";
            echo "<td><span id='id'>" . $r['allyid'] . "</span></td>";
            // echo "<td><img class='ProfileImage' src='../../profile/pictures/" . $r['picture']."'.alt='".$r['picture'] ."'/></td>";
            echo "<td>" . $r['allyname'] . "</td>";
            echo "<td>" . $r['allyfaction'] . "</td>";
            echo "<td>" . $r['allyhomeworld'] . "</td>";
            echo "<td>" . $r['allypower'] . "</td>";
            echo "<td>" . $r['allyusername'] . "</td>";
            echo "</tr>";
          }
          ?>

       </tbody>
     </table>
     

   </div>


   <script>
     $("#Edit").on('click', function() {
    //https://stackoverflow.com/questions/31007427/javascript-get-inner-html-text-for-span-by-class-name/31007547

       var id = $("#UserId").text();
      window.location = "/website/Projects/Phase1/editally.php?id=" + id;
     });
   </script>
   <script>
     $("#allies td").on('click', function() {
       var currentRow = $(this).closest("tr");
       var id = currentRow.find("td span").text();
       window.location = "/website/Projects/Phase1/Allies.php?id=" + id;

     });
   </script>

   <script>
     $("#createnew").on('click', function() {
       window.location = "/website/Projects/Phase1/createally.php";
     });
   </script>

 <?php
    include($root . '/Projects/finalincludes/finalFooter.php');
  } else {
  ?>
   <div class='content'>
     <h2>Allies</h2>


     <table class="table table-bordered table-hover">
       <thead class="thead-dark">
         <tr>
           <th>ID</th>
           <th>Name</th>
           <th>Faction</th>
           <th>Homeworld</th>
           <th>Power</th>
           <th>Username</th>

           <th><button id="createnew">Create New Ally</button></th>
         </tr>

       </thead>
       <tbody id="allies">

         <?php


          foreach ($results as $r) {
            echo "<tr>";
            echo "<td><span id='id'>" . $r['allyid'] . "</span></td>";
            // echo "<td><img class='ProfileImage' src='../../profile/pictures/" . $r['picture']."'.alt='".$r['picture'] ."'/></td>";
            echo "<td>" . $r['allyname'] . "</td>";
            echo "<td>" . $r['allyfaction'] . "</td>";
            echo "<td>" . $r['allyhomeworld'] . "</td>";
            echo "<td>" . $r['allypower'] . "</td>";
            echo "<td>" . $r['allyusername'] . "</td>";
            echo "</tr>";
          }
          ?>

       </tbody>
     </table>
    

   </div>



   <script>
     $("#allies td").on('click', function() {
       var currentRow = $(this).closest("tr");
       var id = currentRow.find("td span").text();
       window.location = "/website/Projects/Phase1/Allies.php?id=" + id;

     });
   </script>

   <script>
     $("#createnew").on('click', function() {
       window.location = "/website/Projects/Phase1/createally.php";
     });
   </script>
    <script>
     $("#Edit").on('click', function() {
      var currentRow = $(this).closest("tr");
       var id = currentRow.find("td span").text();
      window.location = "/website/Projects/Phase1/editally.php?id=" + id;
     });
   </script>
 <?php
    include($root . '/Projects/finalincludes/finalFooter.php');
  }
  ?>