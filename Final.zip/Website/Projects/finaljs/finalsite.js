window.onload = function(){
  var date = new Date();
}

var slideIndex = 0;



function clock() {
  var dt = new Date();
  var d = document.getElementById("currentDate");
  d.innerHTML =dt.toLocaleString();
  setInterval(clock, 1000);
}



